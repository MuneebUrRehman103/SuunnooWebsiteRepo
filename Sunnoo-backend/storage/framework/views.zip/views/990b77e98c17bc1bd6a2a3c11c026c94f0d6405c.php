<?php $__env->startSection('title', tr('add_genre')); ?>

<?php $__env->startSection('content-header'); ?>

    <span style="color:#1d880c !important"><?php echo e($subcategory->name); ?> </span> - <?php echo e(tr('add_genre')); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li><a href="<?php echo e(route('admin.dashboard')); ?>"><i class="fa fa-dashboard"></i><?php echo e(tr('home')); ?></a></li>
    <li><a href="<?php echo e(route('admin.categories')); ?>"><i class="fa fa-suitcase"></i><?php echo e(tr('categories')); ?></a></li>
    <li><a href="<?php echo e(route('admin.sub_categories', array('category' => $subcategory->category_id))); ?>"><i class="fa fa-suitcase"></i> <?php echo e(tr('sub_categories')); ?></a></li>
    <li><a href="<?php echo e(route('admin.genres' , array('sub_category' => $subcategory->id))); ?>"><i class="fa fa-suitcase"></i> <?php echo e(tr('genres')); ?></a></li>
    <li class="active"><i class="fa fa-suitcase"></i> <?php echo e(tr('add_genre')); ?></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('admin.categories.subcategories.genres._form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>