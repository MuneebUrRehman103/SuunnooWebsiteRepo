<?php $__env->startSection('title', tr('sub_profiles')); ?>

<?php $__env->startSection('content-header', tr('sub_profiles')); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li><a href="<?php echo e(route('admin.dashboard')); ?>"><i class="fa fa-dashboard"></i><?php echo e(tr('home')); ?></a></li>
    <li><a href="<?php echo e(route('admin.users')); ?>"> <i class="fa fa-user"></i> <?php echo e(tr('users')); ?></a></li>
    <li class="active"><i class="fa fa-user"></i> <?php echo e(tr('sub_profiles')); ?></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

	<?php echo $__env->make('notification.notify', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<div class="row">
        <div class="col-xs-12">
          <div class="box box-primary">
          	<div class="box-header label-primary">
                <b style="font-size:18px;"><?php echo e(tr('sub_profiles')); ?></b>
               <!--  <a href="<?php echo e(route('admin.add.user')); ?>" class="btn btn-default pull-right"><?php echo e(tr('add_user')); ?></a> -->
            </div>
            <div class="box-body">

            	<?php if(count($users) > 0): ?>

	              	<table id="example1" class="table table-bordered table-striped">

						<thead>
						    <tr>
						      <th><?php echo e(tr('id')); ?></th>
						      <th><?php echo e(tr('username')); ?></th>
						      <th><?php echo e(tr('sub_profile_name')); ?></th>
						      <th><?php echo e(tr('image')); ?></th>
						      <th><?php echo e(tr('action')); ?></th>
						    </tr>
						</thead>

						<tbody>
							<?php foreach($users as $i => $user): ?>

							    <tr>
							      	<td><?php echo e($i+1); ?></td>
							      	<td><?php echo e($user->user->name); ?></td>
							      	<td><?php echo e($user->name); ?></td>
							     	<td><img src="<?php echo e($user->picture); ?>" style="height: 30px;"/></td>
							     	<td>
							     		

							     		<ul class="admin-action btn btn-default">
            								<li class="dropup">
								                <a class="dropdown-toggle" data-toggle="dropdown" href="#">
								                  <?php echo e(tr('action')); ?> <span class="caret"></span>
								                </a>
								                <ul class="dropdown-menu">
								                  	<li role="presentation"><a role="menuitem" tabindex="-1" href="<?php echo e(route('admin.user.history', $user->id)); ?>"><?php echo e(tr('history')); ?></a></li>

								                  	<li role="presentation"><a role="menuitem" tabindex="-1" href="<?php echo e(route('admin.user.wishlist', $user->id)); ?>"><?php echo e(tr('wishlist')); ?></a></li>

								                </ul>

								             </li>
								         </ul>
							     	</td>
							    </tr>
							<?php endforeach; ?>
						</tbody>
					</table>
				<?php else: ?>
					<h3 class="no-result"><?php echo e(tr('no_user_found')); ?></h3>
				<?php endif; ?>
            </div>
          </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>