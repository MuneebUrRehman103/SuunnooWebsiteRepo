<?php $__env->startSection('title', tr('add_category')); ?>

<?php $__env->startSection('content-header', tr('add_category')); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li><a href="<?php echo e(route('admin.dashboard')); ?>"><i class="fa fa-dashboard"></i><?php echo e(tr('home')); ?></a></li>
    <li><a href="<?php echo e(route('admin.categories')); ?>"><i class="fa fa-suitcase"></i> <?php echo e(tr('categories')); ?></a></li>
    <li class="active"><?php echo e(tr('add_category')); ?></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('notification.notify', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="row">

        <div class="col-md-10">

            <div class="box box-primary">

                <div class="box-header label-primary">
                    <b style="font-size:18px;"><?php echo e(tr('add_category')); ?></b>
                    <a href="<?php echo e(route('admin.categories')); ?>" class="btn btn-default pull-right"><?php echo e(tr('categories')); ?></a>
                </div>

                <form class="form-horizontal" action="<?php echo e(route('admin.save.category')); ?>" method="POST" enctype="multipart/form-data" role="form">

                    <div class="box-body">

                        <div class="form-group">
                            <label for="name" class="col-sm-1 control-label"><?php echo e(tr('name')); ?></label>
                            <div class="col-sm-10">
                                <input type="text" required class="form-control" id="name" name="name" placeholder="<?php echo e(tr('category_name')); ?>">
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="picture" class="col-sm-1 control-label"><?php echo e(tr('picture')); ?></label>
                            <div class="col-sm-10">
                                <input type="file" required accept="image/png, image/jpeg" id="picture" name="picture" placeholder="<?php echo e(tr('picture')); ?>">
                                <p class="help-block"><?php echo e(tr('image_validate')); ?> <?php echo e(tr('image_square')); ?></p>
                            </div>
                        </div>

                        <div class="checkbox">
                            <label for="picture" class="col-sm-1 control-label"></label>
                            <label>
                                <input type="checkbox" name="is_series" value="1"> <?php echo e(tr('is_series')); ?>

                            </label>
                        </div>

                    </div>

                    <div class="box-footer">
                        <button type="reset" class="btn btn-danger"><?php echo e(tr('cancel')); ?></button>
                        <?php if(Setting::get('admin_delete_control')): ?>
                            <a href="#" class="btn btn-success pull-right" disabled><?php echo e(tr('submit')); ?></a>
                        <?php else: ?>
                            <button type="submit" class="btn btn-success pull-right"><?php echo e(tr('submit')); ?></button>
                        <?php endif; ?>
                    </div>
                </form>
            
            </div>

        </div>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>