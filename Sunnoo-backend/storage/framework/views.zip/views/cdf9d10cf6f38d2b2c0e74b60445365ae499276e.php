<?php $__env->startSection('title', tr('pages')); ?>

<?php $__env->startSection('content-header', tr('pages')); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li><a href="<?php echo e(route('admin.dashboard')); ?>"><i class="fa fa-dashboard"></i>Home</a></li>
    <li class="active"><i class="fa fa-book"></i> <?php echo e(tr('pages')); ?></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('notification.notify', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="row">
        <div class="col-xs-12">
          <div class="box box-primary">
            <div class="box-header label-primary">
                <b style="font-size:18px;"><?php echo e(tr('pages')); ?></b>
                <a href="<?php echo e(route('static_pages.add')); ?>" class="btn btn-default pull-right"><?php echo e(tr('add_page')); ?></a>
            </div>
            <div class="box-body">

                <?php if(count($data) > 0): ?>

                    <table id="example1" class="table table-bordered table-striped">

                        <thead>
                            <tr>
                                <th>#<?php echo e(tr('id')); ?></th>
                                <th><?php echo e(tr('heading')); ?></th>
                                <th><?php echo e(tr('page_type')); ?></th>
                                <th><?php echo e(tr('action')); ?></th>
                            </tr>
                        </thead>

                        <tbody>

                            <?php foreach($data as $i => $value): ?>
                    
                                <tr>
                                    <td><?php echo e($i+1); ?></td>
                                    <td><a href="<?php echo e(Setting::get('ANGULAR_SITE_URL')); ?>page/<?php echo e($value->id); ?>" target="_blank"><?php echo e($value->heading); ?></a></td>
                                    <td><?php echo e($value->type); ?></td>
                                    <td>
                                        <ul class="admin-action btn btn-default">
                                            <li class="dropdown">
                                                
                                                <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                                                  <?php echo e(tr('action')); ?> <span class="caret"></span>
                                                </a>

                                                <ul class="dropdown-menu">
                                                   
                                                    <li role="presentation">
                                                        <a role="menuitem" tabindex="-1" href="<?php echo e(route('static_pages.edit', array('id' => $value->id))); ?>">
                                                            <?php echo e(tr('edit_page')); ?>

                                                        </a>
                                                    </li>

                                                    
                                                    <li role="presentation">
                                                        <?php if(Setting::get('admin_delete_control')): ?>

                                                            <a role="button" href="javascript:;" class="btn disabled" style="text-align: left"><?php echo e(tr('delete')); ?></a>

                                                        <?php else: ?>
                                                            <a role="menuitem" tabindex="-1" onclick="return confirm('Are you sure?');" href="<?php echo e(route('static_pages.delete',array('id' => $value->id))); ?>">
                                                                <?php echo e(tr('delete_page')); ?>

                                                            </a>
                                                        <?php endif; ?>
                                                    </li>

                                                </ul>

                                            </li>
                                        
                                        </ul>
                                    </td>
                                </tr>
                            <?php endforeach; ?>

                        </tbody>
                    </table>
                <?php else: ?>
                    <h3 class="no-result"><?php echo e(tr('no_result_found')); ?></h3>
                <?php endif; ?>
            </div>
          </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>