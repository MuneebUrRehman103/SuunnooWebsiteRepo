<?php $__env->startSection('title', tr('categories')); ?>

<?php $__env->startSection('content-header', tr('categories')); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li><a href="<?php echo e(route('admin.dashboard')); ?>"><i class="fa fa-dashboard"></i><?php echo e(tr('home')); ?></a></li>
    <li class="active"><i class="fa fa-suitcase"></i> <?php echo e(tr('categories')); ?></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

	<?php echo $__env->make('notification.notify', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<div class="row">
        <div class="col-xs-12">
          <div class="box box-primary">
          	<div class="box-header label-primary">
                <b style="font-size:18px;"><?php echo e(tr('categories')); ?></b>
                <a href="<?php echo e(route('admin.add.category')); ?>" class="btn btn-default pull-right"><?php echo e(tr('add_category')); ?></a>
            </div>
            <div class="box-body">

            	<?php if(count($categories) > 0): ?>

	              	<table id="example1" class="table table-bordered table-striped">

						<thead>
						    <tr>
						      <th><?php echo e(tr('id')); ?></th>
						      <th><?php echo e(tr('category')); ?></th>
						      <th><?php echo e(tr('picture')); ?></th>
						      <th><?php echo e(tr('is_series')); ?></th>
						      <th><?php echo e(tr('status')); ?></th>
						      <th><?php echo e(tr('action')); ?></th>
						    </tr>
						</thead>

						<tbody>
							<?php foreach($categories as $i => $category): ?>

							    <tr>
							      	<td><?php echo e($i+1); ?></td>
							      	<td><?php echo e($category->name); ?></td>
							      	<td>
	                                	<img style="height: 30px;" src="<?php echo e($category->picture); ?>">
	                            	</td>

	                            	<td>
							      		<?php if($category->is_series): ?>
							      			<span class="label label-success"><?php echo e(tr('yes')); ?></span>
							       		<?php else: ?>
							       			<span class="label label-warning"><?php echo e(tr('no')); ?></span>
							       		<?php endif; ?>
							       	</td>

							      <td>
							      		<?php if($category->is_approved): ?>
							      			<span class="label label-success"><?php echo e(tr('approved')); ?></span>
							       		<?php else: ?>
							       			<span class="label label-warning"><?php echo e(tr('pending')); ?></span>
							       		<?php endif; ?>
							       </td>
							      <td>
            							<ul class="admin-action btn btn-default">
            								
            								<li class="dropup">
            								
								                <a class="dropdown-toggle" data-toggle="dropdown" href="#">
								                  <?php echo e(tr('action')); ?> <span class="caret"></span>
								                </a>
								                <ul class="dropdown-menu">
								                  	<li role="presentation">
                                                        <?php if(Setting::get('admin_delete_control')): ?>
                                                            <a role="button" href="javascript:;" class="btn disabled" style="text-align: left"><?php echo e(tr('edit')); ?></a>
                                                        <?php else: ?>
                                                            <a role="menuitem" tabindex="-1" href="<?php echo e(route('admin.edit.category' , array('id' => $category->id))); ?>"><?php echo e(tr('edit')); ?></a>
                                                        <?php endif; ?>
                                                    </li>
								                  	<li role="presentation">

									                  	<?php if(Setting::get('admin_delete_control')): ?>

										                  	<a role="button" href="javascript:;" class="btn disabled" style="text-align: left"><?php echo e(tr('delete')); ?></a>

										                <?php else: ?>

								                  			<a role="menuitem" tabindex="-1" onclick="return confirm('Are you sure?')" href="<?php echo e(route('admin.delete.category' , array('category_id' => $category->id))); ?>"><?php echo e(tr('delete')); ?></a>
								                  		<?php endif; ?>
								                  	</li>

													<li class="divider" role="presentation"></li>

								                  	<?php if($category->is_approved): ?>
								                  		<li role="presentation"><a role="menuitem" tabindex="-1" href="<?php echo e(route('admin.category.approve' , array('id' => $category->id , 'status' =>0))); ?>"><?php echo e(tr('decline')); ?></a></li>
								                  	<?php else: ?>
								                  		<li role="presentation"><a role="menuitem" tabindex="-1" href="<?php echo e(route('admin.category.approve' , array('id' => $category->id , 'status' => 1))); ?>"><?php echo e(tr('approve')); ?></a></li>
								                  	<?php endif; ?>

								                  	<li class="divider" role="presentation"></li>

								                  	<li role="presentation"><a role="menuitem" tabindex="-1" href="<?php echo e(route('admin.add.sub_category' , array('category' => $category->id))); ?>"><?php echo e(tr('add_sub_category')); ?></a></li>
								                  	<li role="presentation"><a role="menuitem" tabindex="-1" href="<?php echo e(route('admin.sub_categories' , array('category' => $category->id))); ?>"><?php echo e(tr('view_sub_categories')); ?></a></li>
								                </ul>
              								</li>
            							</ul>
							      </td>
							    </tr>
							<?php endforeach; ?>
						</tbody>
					</table>
				<?php else: ?>
					<h3 class="no-result"><?php echo e(tr('no_result_found')); ?></h3>
				<?php endif; ?>
            </div>
          </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>