<aside class="main-sidebar">

    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">

        <!-- Sidebar user panel -->
        <div class="user-panel">
            <div class="pull-left image">
                <img src="<?php if(Auth::guard('moderator')->user()->picture): ?><?php echo e(Auth::guard('moderator')->user()->picture); ?> <?php else: ?> <?php echo e(asset('admin-css/dist/img/avatar.png')); ?> <?php endif; ?>" class="img-circle" alt="User Image">
            </div>
            <div class="pull-left info">
                <p><?php echo e(Auth::guard('moderator')->user()->name); ?></p>
                <a href="<?php echo e(route('moderator.profile')); ?>"><?php echo e(tr('moderator')); ?></a>
            </div>
        </div>

        <!-- sidebar menu: : style can be found in sidebar.less -->
        <ul class="sidebar-menu">

            <li id="dashboard">
                <a href="<?php echo e(route('moderator.dashboard')); ?>">
                    <i class="fa fa-dashboard"></i> <span><?php echo e(tr('dashboard')); ?></span>
                </a>
            </li>

            <li class="treeview" id="videos">
                <a href="<?php echo e(route('moderator.videos')); ?>">
                    <i class="fa fa-video-camera"></i> <span><?php echo e(tr('videos')); ?></span><i class="fa fa-angle-left pull-right"></i>
                </a>

                <ul class="treeview-menu">
                    <li id="add-video"><a href="<?php echo e(route('moderator.add.video')); ?>"><i class="fa fa-circle-o"></i><?php echo e(tr('add_video')); ?></a></li>
                    <li id="view-videos"><a href="<?php echo e(route('moderator.videos')); ?>"><i class="fa fa-circle-o"></i><?php echo e(tr('view_videos')); ?></a></li>
                </ul>

            </li>


             <li class="treeview" id="revenue">
                <a href="<?php echo e(route('moderator.user.video-payments')); ?>">
                    <i class="fa fa-money"></i> <span><?php echo e(tr('revenue')); ?> </span><i class="fa fa-angle-left pull-right"></i>
                </a>

                <ul class="treeview-menu">
                    <li id="video-payments"><a href="<?php echo e(route('moderator.user.video-payments')); ?>"><i class="fa fa-circle-o"></i><?php echo e(tr('ppv_payments')); ?></a></li>
                     <li id="redeem-index"><a href="<?php echo e(route('moderator.redeems')); ?>"><i class="fa fa-circle-o"></i><?php echo e(tr('redeem_request')); ?></a></li>
                    <li id="revenues"><a href="<?php echo e(route('moderator.revenues')); ?>"><i class="fa fa-circle-o"></i><?php echo e(tr('revenues')); ?></a></li>
                    
                </ul>

            </li>

            <li id="profile">
                <a href="<?php echo e(route('moderator.profile')); ?>">
                    <i class="fa fa-diamond"></i> <span><?php echo e(tr('profile')); ?></span>
                </a>
            </li>

            <li>
                <a href="<?php echo e(route('moderator.logout')); ?>">
                    <i class="fa fa-sign-out"></i> <span><?php echo e(tr('sign_out')); ?></span>
                </a>
            </li>

        </ul>

    </section>

    <!-- /.sidebar -->

</aside>