<?php $__env->startSection('title', tr('help')); ?>

<?php $__env->startSection('content-header', tr('help')); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li><a href="<?php echo e(route('admin.dashboard')); ?>"><i class="fa fa-dashboard"></i><?php echo e(tr('home')); ?></a></li>
    <li class="active"><i class="fa fa-question-circle"></i> <?php echo e(tr('help')); ?></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">

    <div class="col-md-12">

    	<div class="box box-success">
            <div class="box-header with-border">
                <h3 class="box-title"><?php echo e(tr('help')); ?></h3>
            </div>

            <div class="box-body">

            	<div class="card">


			       	<div class="card-head style-primary">
			            <header><?php echo e(tr('hi_there')); ?></header>
			        </div>

            		<div class="card-body help">
		                <p>
		                 <?php echo e(tr('thanks_for_choosing_streamhash')); ?>

		                </p>

		                <p>
		                 <?php echo e(tr('any_changes_your_site')); ?>

		                </p>

		                <a href="https://www.facebook.com/StreamHash/" target="_blank"><img class="aligncenter size-full wp-image-159 help-image" src="http://default.streamhash.com/helpsocial/Facebook.png" alt="Facebook-100" width="100" height="100" /></a>
		                &nbsp;

		                <a href="https://twitter.com/StreamHash" target="_blank"><img class="size-full wp-image-155 alignleft help-image" src="http://default.streamhash.com/helpsocial/twitter.png " alt="Twitter" width="100" height="100" /></a>
		                &nbsp;

		                <a href="skype:contact@streamhash.com?chat" target="_blank"> <img class="wp-image-158 alignleft help-image" src="http://default.streamhash.com/helpsocial/skype.png" alt="skype" width="100" height="100" /></a>
		                &nbsp;

		                <a href="mailto:contact@streamhash.com" target="_blank"><img class="size-full wp-image-153 alignleft help-image" src="http://default.streamhash.com/helpsocial/mail.png" alt="Message-100" width="100" height="100" /></a>

			             &nbsp;


			             <p><?php echo e(tr('help_notes_streamhash')); ?></p>

              			<a href="#" target="_blank"><img class="aligncenter help-image size-full wp-image-160" src="http://default.streamhash.com/helpsocial/Money-Box-100.png" alt="Money Box-100" width="100" height="100" /></a>

						<p><?php echo e(tr('cheers')); ?></p>

            		</div>

        		</div>

    		</div>
        </div>

    </div>

</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>