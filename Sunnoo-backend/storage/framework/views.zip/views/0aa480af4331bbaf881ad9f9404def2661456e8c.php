<?php $__env->startSection('title', tr('view_subscription')); ?>

<?php $__env->startSection('content-header', tr('view_subscription')); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li><a href="<?php echo e(route('admin.dashboard')); ?>"><i class="fa fa-dashboard"></i><?php echo e(tr('home')); ?></a></li>
    <li><a href="<?php echo e(route('admin.subscriptions.index')); ?>"><i class="fa fa-key"></i> <?php echo e(tr('subscriptions')); ?></a></li>
    <li class="active"><i class="fa fa-eye"></i>&nbsp;<?php echo e(tr('view_subscriptions')); ?></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

	<style type="text/css">
		.timeline::before {
		    content: '';
		    position: absolute;
		    top: 0;
		    bottom: 0;
		    width: 0;
		    background: #fff;
		    left: 0px;
		    margin: 0;
		    border-radius: 0px;
		}
	</style>


	<?php echo $__env->make('notification.notify', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	
	<div class="row">

		<div class="col-md-6 col-md-offset-3">

			<div class="box box-primary">

				<div class="box-header btn btn-primary with-border">
					<div class="pull-left">
						<h3 class="box-title" style="color: white"><b><?php echo e(tr('subscription')); ?></b></h3>
					</div>
					<div class="pull-right">
		      			<a href="<?php echo e(route('admin.subscriptions.status' , $data->unique_id)); ?>" class="btn btn-sm <?php echo e($data->status ? 'btn-warning' : 'btn-success'); ?>">
		      				<?php if($data->status): ?> 
      							<i class="fa fa-close"></i>&nbsp;&nbsp;<?php echo e(tr('decline')); ?>

      						<?php else: ?> 
      							<i class="fa fa-check"></i>&nbsp;&nbsp;<?php echo e(tr('approve')); ?>

      						<?php endif; ?>
      					</a>
						<a href="<?php echo e(route('admin.subscriptions.edit',$data->unique_id)); ?>" class="btn btn-sm btn-warning"><i class="fa fa-pencil"></i> <?php echo e(tr('edit')); ?></a>
					</div>
					<div class="clearfix"></div>
				</div>

				<div class="box-body">

					<strong><i class="fa fa-book margin-r-5"></i> <?php echo e(tr('title')); ?></strong>

					<p class="text-muted"><?php echo e($data->title); ?></p>

					<hr>

					<strong><i class="fa fa-book margin-r-5"></i> <?php echo e(tr('description')); ?></strong>

					<p class="text-muted"><?php echo e($data->description); ?></p>

					<hr>

					<strong><i class="fa fa-calendar margin-r-5"></i> <?php echo e(tr('no_of_months')); ?></strong>
					<br>
					<br>

					<p>
					<span class="label label-success" style="padding: 5px 10px;margin: 5px;font-size: 18px"><b><?php echo e($data->plan); ?></b></span>
					
					</p>

					<hr>

					<strong><i class="fa fa-money margin-r-5"></i> <?php echo e(tr('amount')); ?></strong>

					<br>
					<br>

					<p><span class="label label-danger" style="padding: 5px 10px;margin: 5px;font-size: 18px"><b><?php echo e(Setting::get('currency' , "$")); ?> <?php echo e($data->amount); ?></b></span>
					</p>

					<hr>

					<strong><i class="fa fa-users margin-r-5"></i> <?php echo e(tr('no_of_account')); ?></strong>

					<br>
					<br>

					<p><span class="label label-danger" style="padding: 5px 10px;margin: 5px;font-size: 18px"><b><?php echo e($data->no_of_account); ?></b></span>
					</p>

				</div>

			</div>
			<!-- /.box -->
		</div>

    </div>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>