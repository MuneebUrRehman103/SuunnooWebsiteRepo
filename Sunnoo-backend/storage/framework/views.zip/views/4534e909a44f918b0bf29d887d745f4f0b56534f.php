
<?php echo $__env->make('notification.notify', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="row">

        <div class="col-md-10">

            <div class="box box-primary">

                <div class="box-header label-primary">
                    <b style="font-size:18px;"><?php echo $__env->yieldContent('title'); ?></b>
                    <a href="<?php echo e(route('admin.genres' , array('sub_category' => $subcategory->id))); ?>" class="btn btn-default pull-right"><?php echo e(tr('genres')); ?></a>
                </div>

                <form class="form-horizontal" action="<?php echo e(route('admin.save.genre')); ?>" method="POST" enctype="multipart/form-data" role="form">

                    <div class="box-body">

                        <input type="hidden" name="sub_category_id" value="<?php echo e($subcategory->id); ?>">

                        <input type="hidden" name="category_id" value="<?php echo e($subcategory->category_id); ?>">

                        <input type="hidden" name="id" value="<?php echo e($genre->id); ?>">

                        <div class="form-group">
                            <label for="name" class="col-sm-2 control-label"><?php echo e(tr('name')); ?></label>
                            <div class="col-sm-10">
                                <input type="text" required class="form-control" id="name" name="name" placeholder="<?php echo e(tr('name')); ?>" value="<?php echo e($genre->name); ?>">
                            </div>
                        </div>

                        <div class="form-group">

                            <label for="picture1" class="col-sm-2 control-label"><?php echo e(tr('image')); ?></label>

                            <div class="col-sm-10">
                                <input type="file" accept="image/png,image/jpeg" id="image" name="image" placeholder="<?php echo e(tr('image')); ?>" <?php if(!$genre->id): ?> required <?php endif; ?>>
                                 <p class="help-block"><?php echo e(tr('image_validate')); ?> <?php echo e(tr('rectangle_image')); ?></p>
                            </div>
                        </div>

                    

                        <div class="form-group">

                            <label for="picture1" class="col-sm-2 control-label"><?php echo e(tr('trailer_video')); ?></label>

                            <div class="col-sm-10">
                                <input type="file" accept="video/mp4" id="video" name="video" placeholder="<?php echo e(tr('video')); ?>" <?php if(!$genre->id): ?> required <?php endif; ?>>
                                 <p class="help-block"><?php echo e(tr('video_validate')); ?></p>
                            </div>
                        </div>



                        <div class="form-group">
                            <label for="video" class="col-sm-2 control-label"><?php echo e(tr('sub_title')); ?></label>

                            <div class="col-sm-10">
                            <input type="file" id="subtitle" name="subtitle" accept="text/plain">
                            <p class="help-block"><?php echo e(tr('subtitle_validate')); ?></p>

                            </div>
                        </div>
                    
                      

                    </div>

                    <div class="box-footer">
                        <button type="reset" class="btn btn-danger"><?php echo e(tr('cancel')); ?></button>
                        <?php if(Setting::get('admin_delete_control')): ?>
                            <a href="#" class="btn btn-success pull-right" disabled><?php echo e(tr('submit')); ?></a>
                        <?php else: ?>
                            <button type="submit" class="btn btn-success pull-right"><?php echo e(tr('submit')); ?></button>
                        <?php endif; ?>
                    </div>
                </form>
            
            </div>

        </div>

    </div>
