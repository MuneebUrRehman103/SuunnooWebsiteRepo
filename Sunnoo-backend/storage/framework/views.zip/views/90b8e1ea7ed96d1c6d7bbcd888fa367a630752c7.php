<?php $__env->startSection('title', tr('subscriptions')); ?>

<?php $__env->startSection('content-header', tr('subscriptions')); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li><a href="<?php echo e(route('admin.dashboard')); ?>"><i class="fa fa-dashboard"></i><?php echo e(tr('home')); ?></a></li>
    <li class="active"><i class="fa fa-key"></i> <?php echo e(tr('subscriptions')); ?></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

	<?php echo $__env->make('notification.notify', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<div class="row">
        <div class="col-xs-12">
          <div class="box box-primary">

          	<div class="box-header label-primary">
                <b><?php echo e(tr('subscriptions')); ?></b>
                <a href="<?php echo e(route('admin.subscriptions.create')); ?>" style="float:right" class="btn btn-default"><?php echo e(tr('add_subscription')); ?></a>
            </div>
            
            <div class="box-body">

              	<table id="example1" class="table table-bordered table-striped">

					<thead>
					    <tr>
					      	<th><?php echo e(tr('id')); ?></th>
					      	<th><?php echo e(tr('title')); ?></th>
					      	<th><?php echo e(tr('no_of_months')); ?></th>
					      	<th><?php echo e(tr('amount')); ?></th>
					      	<th><?php echo e(tr('status')); ?></th>
					      	<th><?php echo e(tr('popular')); ?></th>
					      	<th><?php echo e(tr('no_of_account')); ?></th>
					      	<th><?php echo e(tr('subscribers')); ?></th>
					      	<th><?php echo e(tr('action')); ?></th>
					    </tr>
					</thead>

					<tbody>
					
						<?php foreach($data as $i => $value): ?>

						    <tr>
						      	<td><?php echo e($i+1); ?></td>
						      	<td><?php echo e($value->title); ?></td>
						      	<td><?php echo e($value->plan); ?></td>
						      	<td><?php echo e(Setting::get('currency' , "$")); ?> <?php echo e($value->amount); ?></td>

						      	<td class="text-center">

					      			<?php if($value->status): ?>
						      			<span class="label label-success"><?php echo e(tr('approved')); ?></span>
						      		<?php else: ?>
						      			<span class="label label-warning"><?php echo e(tr('pending')); ?></span>
						      		<?php endif; ?>
						      	</td>

						      	<td class="text-center">

					      			<?php if($value->popular_status): ?>

					      				<a href="<?php echo e(route('admin.subscriptions.popular.status' , $value->unique_id)); ?>" class="btn  btn-xs btn-danger">
				              				<?php echo e(tr('remove_popular')); ?>

				              			</a>

						      		<?php else: ?>

						      			<a href="<?php echo e(route('admin.subscriptions.popular.status' , $value->unique_id)); ?>" class="btn  btn-xs btn-success">

				              				<?php echo e(tr('mark_popular')); ?>


				              			</a>


						      		<?php endif; ?>
						      		
						      	</td>

						      	<td><?php echo e($value->no_of_account); ?></td>

						      	<td><a href="<?php echo e(route('admin.subscriptions.users' , $value->id)); ?>"> <?php echo e($value->userSubscription()->where('status' , 1)->count()); ?></a></td>
						      
								<td>
									<ul class="admin-action btn btn-default">

										<li class="dropdown">

								            <a class="dropdown-toggle" data-toggle="dropdown" href="#">
								              <?php echo e(tr('action')); ?> <span class="caret"></span>
								            </a>

								            <ul class="dropdown-menu">

								              	<li role="presentation">
								              		<a role="menuitem" tabindex="-1" href="<?php echo e(route('admin.subscriptions.edit' , $value->unique_id)); ?>"><i class="fa fa-edit"></i>&nbsp;<?php echo e(tr('edit')); ?>

								              		</a>
								              	</li>

								              	<li role="presentation">
								              		<a role="menuitem" tabindex="-1" href="<?php echo e(route('admin.subscriptions.view' , $value->unique_id)); ?>"><span class="text-blue"><b><i class="fa fa-eye"></i>&nbsp;<?php echo e(tr('view')); ?></b></span>
								              		</a>
								              	</li>

								    
								              	<li role="presentation" class="divider"></li>

								              	<li role="presentation">
								              			<a role="menuitem" tabindex="-1" href="<?php echo e(route('admin.subscriptions.users' , $value->id)); ?>">
								              				<span class="text-green"><b><i class="fa fa-user"></i>&nbsp;<?php echo e(tr('subscribers')); ?></b></span>
								              			</a>
								              		</li>
								              	
								              	<li role="presentation" class="divider"></li>

								              	<?php if($value->status): ?>

								              		<li role="presentation">
								              			<a role="menuitem" tabindex="-1" href="<?php echo e(route('admin.subscriptions.status' , $value->unique_id)); ?>">
								              				<span class="text-red"><b><i class="fa fa-close"></i>&nbsp;<?php echo e(tr('decline')); ?></b></span>
								              			</a>
								              		</li>

								              	<?php else: ?>

													<li role="presentation">
								              			<a role="menuitem" tabindex="-1" href="<?php echo e(route('admin.subscriptions.status' , $value->unique_id)); ?>">
								              				<span class="text-green"><b><i class="fa fa-check"></i>&nbsp;<?php echo e(tr('approve')); ?></b></span>
								              			</a>
								              		</li>								              	

								              	<?php endif; ?>								       								              									        
								              	<li role="presentation" class="divider"></li>								            

								              	<li role="presentation">

													<?php if(Setting::get('admin_delete_control')): ?>
														<a role="button" href="javascript:;" class="btn disabled" style="text-align: left"><i class="fa fa-trash"></i>&nbsp;<?php echo e(tr('delete')); ?></a>
													<?php else: ?>
														<a role="menuitem" tabindex="-1" onclick="return confirm('Are you sure?');" href="<?php echo e(route('admin.subscriptions.delete', array('id' => $value->id))); ?>"><i class="fa fa-trash"></i>&nbsp;<?php echo e(tr('delete')); ?></a>
													<?php endif; ?>						

								              	</li>

								            </ul>
										
										</li>
									</ul>

								</td>
						    </tr>
						<?php endforeach; ?>
					</tbody>
				
				</table>
			
            </div>
          </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<script type="text/javascript">
window._pcq = window._pcq || [];
_pcq.push(['APIReady', callbackOnAPIReady]); //will execute callback function when PushCrew API is ready

_pcq.push(['subscriptionSuccessCallback',callbackOnSuccessfulSubscription]); //registers callback function to be called when user gets successfully subscribed

function callbackOnAPIReady() {
    //now api is ready
    _pcq.push(['addSubscriberToSegment', 'homepage', callbackForAddToSegment]);
}

function callbackOnSuccessfulSubscription(subscriberId, values) {
    //user just got subscribed
    _pcq.push(['addSubscriberToSegment', 'homepage', callbackForAddToSegment]);
}

function callbackForAddToSegment(response) {
    if(response === -1) {
        console.log('User is not a subscriber or has blocked notifications');
    }
  
    if(response === false) {
        console.log('Segment name provided is not valid. Maximum length of segment name can be 30 chars and it can only contain alphanumeric characters, underscore and dash.');
    }
  
    if(response === true) {
        console.log('User got added to the segment successfully. Now you may run any code you wish to execute after user gets added to segment successfully');
    }
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>