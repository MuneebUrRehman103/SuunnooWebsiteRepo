<?php $__env->startSection('title', tr('genres')); ?>

<?php $__env->startSection('content-header'); ?>

	<span style="color:#1d880c !important"><?php echo e($sub_category->name); ?> </span> - <?php echo e(tr('genres')); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li><a href="<?php echo e(route('admin.dashboard')); ?>"><i class="fa fa-dashboard"></i><?php echo e(tr('home')); ?></a></li>
     <li><a href="<?php echo e(route('admin.categories')); ?>"><i class="fa fa-suitcase"></i><?php echo e(tr('categories')); ?></a></li>
    <li><a href="<?php echo e(route('admin.sub_categories', array('category' => $sub_category->category_id))); ?>"><i class="fa fa-suitcase"></i> <?php echo e(tr('sub_categories')); ?></a></li>
    <li class="active"><i class="fa fa-suitcase"></i> <?php echo e(tr('genres')); ?></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('notification.notify', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<div class="row">
        <div class="col-xs-12">
          <div class="box box-primary">
          	<div class="box-header label-primary">
                <b style="font-size:18px;"><?php echo e(tr('genres')); ?></b>
                <a href="<?php echo e(route('admin.add.genre' , array('sub_category' => $sub_category->id))); ?>" class="btn btn-default pull-right"><?php echo e(tr('add_genre')); ?></a>
            </div>
            <div class="box-body">

            	<?php if(count($data) > 0): ?>

	              	<table id="example1" class="table table-bordered table-striped">

						<thead>
						    <tr>
						      <th><?php echo e(tr('id')); ?></th>
						      <th><?php echo e(tr('category')); ?></th>
						      <th><?php echo e(tr('sub_category')); ?></th>
						      <th><?php echo e(tr('genre')); ?></th>
						      <th><?php echo e(tr('position')); ?></th>
						      <th><?php echo e(tr('image')); ?></th>
						      <th><?php echo e(tr('status')); ?></th>
						      <th><?php echo e(tr('action')); ?></th>
						    </tr>
						</thead>

						<tbody>

							<?php foreach($data as $i => $value): ?>


							    <tr>
							      	<td><?php echo e($i+1); ?></td>
							      	<td><?php echo e($value->category_name); ?></td>
							      	<td><?php echo e($value->sub_category_name); ?></td>
							      	<td><?php echo e($value->genre_name); ?></td>
							      	<td>

							      	<?php if($value->position > 0): ?>

							      	<span class="label label-success"><?php echo e($value->position); ?></span>

							      	<?php else: ?>

							      	<span class="label label-danger"><?php echo e($value->position); ?></span>

							      	<?php endif; ?>
							      	</td>
							      	<td>
	                                	<img style="height: 30px;" src="<?php echo e($value->image); ?>">
	                            	</td>
							      	<td>
							      		<?php if($value->is_approved): ?>
							      			<span class="label label-success"><?php echo e(tr('approved')); ?></span>
							       		<?php else: ?>
							       			<span class="label label-warning"><?php echo e(tr('pending')); ?></span>
							       		<?php endif; ?>
							       </td>


								    <td>
            							<ul class="admin-action btn btn-default">
            								<li class="dropup">
								                <a class="dropdown-toggle" data-toggle="dropdown" href="#">
								                  <?php echo e(tr('action')); ?> <span class="caret"></span>
								                </a>
								                <ul class="dropdown-menu">

								                	<li role="presentation">
								                		<a role="menuitem" tabindex="-1" href="<?php echo e(route('admin.view.genre' , array('id' => $value->genre_id))); ?>"><?php echo e(tr('view_genre')); ?></a>
								                	</li>

								                	<?php if($value->is_approved): ?>

								                	<li role="presentation">
								                		<a role="menuitem" tabindex="-1" role="menuitem" tabindex="-1" data-toggle="modal" data-target="#genre_<?php echo e($value->genre_id); ?>"><?php echo e(tr('change_position')); ?></a>
								                	</li>

								                	<?php endif; ?>

								                  	<li role="presentation">
														<?php if(Setting::get('admin_delete_control')): ?>
                                                            <a role="button" href="javascript:;" class="btn disabled" style="text-align: left"><?php echo e(tr('edit')); ?></a>
                                                        <?php else: ?>
															<a role="menuitem" tabindex="-1" href="<?php echo e(route('admin.edit.edit_genre' , array('sub_category_id' => $value->sub_category_id,'genre_id' => $value->genre_id))); ?>"><?php echo e(tr('edit')); ?></a>
														<?php endif; ?>

													</li>

								                  	<li class="divider" role="presentation"></li>

								                  	<?php 

								                  	$approve = tr('approve_genre');

								                  	$decline = tr('decline_genre');

								                  	$delete = tr('delete_genre');

								                  	?>

								                  	<?php if($value->is_approved): ?>
								                  		<li role="presentation"><a role="menuitem" tabindex="-1" href="<?php echo e(route('admin.genre.approve' , array('id' => $value->genre_id , 'status' =>0))); ?>" onclick="return confirm('<?php echo e($decline); ?>')"><?php echo e(tr('decline')); ?></a></li>
								                  	<?php else: ?>
								                  		<li role="presentation"><a role="menuitem" tabindex="-1" href="<?php echo e(route('admin.genre.approve' , array('id' => $value->genre_id , 'status' => 1))); ?>" onclick="return confirm('<?php echo e($approve); ?>')"><?php echo e(tr('approve')); ?></a></li>
								                  	<?php endif; ?>


								                  	<li role="presentation">

								                  		<?php if(Setting::get('admin_delete_control')): ?>

									                  	 	<a role="button" href="javascript:;" class="btn disabled" style="text-align: left"><?php echo e(tr('delete')); ?></a>

									                  	 <?php else: ?>

								                  			<a role="menuitem" onclick="return confirm('<?php echo e($delete); ?>')" tabindex="-1" href="<?php echo e(route('admin.delete.genre' , array('id' => $value->genre_id))); ?>"><?php echo e(tr('delete')); ?></a>
								                  		<?php endif; ?>

								                  	</li>
								              
								                </ul>
              								</li>
            							</ul>
								    </td>
							    </tr>
							    <div id="genre_<?php echo e($value->genre_id); ?>" class="modal fade" role="dialog">
								  <div class="modal-dialog">
								  <form action="<?php echo e(route('admin.save.genre.position',['genre_id'=>$value->genre_id])); ?>" method="POST">
									    <!-- Modal content-->
									   	<div class="modal-content">
									      <div class="modal-header">
									        <button type="button" class="close" data-dismiss="modal">&times;</button>
									        <h4 class="modal-title"><?php echo e(tr('change_position')); ?></h4>
									      </div>

									      <div class="modal-body">
									        
								            <div class="row">
									        	<div class="col-lg-3">
									        		<label><?php echo e(tr('position')); ?></label>
									        	</div>
								                <div class="col-lg-9">
								                       <input type="number" required value="<?php echo e($value->position); ?>" name="position" class="form-control" id="position" placeholder="<?php echo e(tr('position')); ?>" pattern="[0-9]{1,}" title="Enter 0-9 numbers">
								                  <!-- /input-group -->
								                </div>
								            </div>
									      </div>
									      <div class="modal-footer">
									        <div class="pull-right">
										        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
										        <button type="submit" class="btn btn-primary"><?php echo e(tr('submit')); ?></button>
										    </div>
										    <div class="clearfix"></div>
									      </div>
									    </div>
									</form>
								  </div>
								</div>
							<?php endforeach; ?>
						</tbody>
					</table>
				<?php else: ?>
					<h3 class="no-result"><?php echo e(tr('no_genre')); ?></h3>
				<?php endif; ?>
            </div>
          </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>