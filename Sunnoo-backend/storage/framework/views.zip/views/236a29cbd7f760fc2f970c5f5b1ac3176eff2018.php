<?php $__env->startSection('title', tr('edit_page')); ?>

<?php $__env->startSection('content-header', tr('edit_page')); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li><a href="<?php echo e(route('admin.dashboard')); ?>"><i class="fa fa-dashboard"></i><?php echo e(tr('home')); ?></a></li>
    <li><a href="<?php echo e(route('static_pages.index')); ?>"><i class="fa fa-book"></i> <?php echo e(tr('pages')); ?></a></li>
    <li class="active"> <?php echo e(tr('edit_page')); ?></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('notification.notify', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="row">

    <div class="col-md-10">

        <div class="box box-primary">

            <div class="box-header label-primary">
                <b style="font-size:18px;"><?php echo e(tr('pages')); ?></b>
                <a href="<?php echo e(route('static_pages.add')); ?>" class="btn btn-default pull-right"><?php echo e(tr('add_page')); ?></a>
            </div>

            <form  action="<?php echo e((Setting::get('admin_delete_control') == 1) ? '' : route('static_pages.edit.save')); ?>" method="POST" enctype="multipart/form-data" role="form">

                <div class="box-body">
                    <input type="hidden" name="id" value="<?php echo e($data->id); ?>">

                    <div class="form-group">
                        <label for="heading"><?php echo e(tr('heading')); ?></label>
                        <input type="text" class="form-control" name="heading" value="<?php echo e($data->heading); ?>" id="heading" placeholder="<?php echo e(tr('enter')); ?> <?php echo e(tr('heading')); ?>">
                    </div>

                    <div class="form-group">
                        <label for="description"><?php echo e(tr('description')); ?></label>

                        <textarea id="ckeditor" name="description" class="form-control" placeholder="<?php echo e(tr('enter')); ?> <?php echo e(tr('description')); ?>"><?php echo e($data->description); ?></textarea>
                        
                    </div>

                </div>

              <div class="box-footer">
                    <button type="reset" class="btn btn-danger"><?php echo e(tr('cancel')); ?></button>
                    <?php if(Setting::get('admin_delete_control') == 1): ?> 
                        <button type="submit" class="btn btn-success pull-right" disabled><?php echo e(tr('submit')); ?></button>
                    <?php else: ?>
                        <button type="submit" class="btn btn-success pull-right"><?php echo e(tr('submit')); ?></button>
                    <?php endif; ?>
              </div>

            </form>
        
        </div>

    </div>

</div>
   
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="https://cdn.ckeditor.com/4.5.5/standard/ckeditor.js"></script>
    <script>
        CKEDITOR.replace( 'ckeditor' );
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>