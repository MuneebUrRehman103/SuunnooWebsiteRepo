<?php $__env->startSection('title', tr('dashboard')); ?>

<?php $__env->startSection('content-header', tr('dashboard')); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li class="active"><i class="fa fa-dashboard"></i> <?php echo e(tr('dashboard')); ?></a></li>
<?php $__env->stopSection(); ?>

<style type="text/css">
  .center-card{
    	width: 30% !important;
	}
  .small-box .icon {
    top: 0px !important;
  }
</style>

<?php $__env->startSection('content'); ?>

	<div class="row">

		<!-- Total Users -->
	
         <div class="col-lg-3 col-xs-6">

          	<div class="small-box bg-yellow">
            	<div class="inner">
              		<h3><?php echo e($today_videos); ?></h3>
              		<p><?php echo e(tr('total_videos')); ?></p>
            	</div>
            	
            	<div class="icon">
              		<i class="fa fa-video-camera"></i>
            	</div>

            	<a target="_blank" href="<?php echo e(route('moderator.videos')); ?>" class="small-box-footer">
              		<?php echo e(tr('more_info')); ?>

              		<i class="fa fa-arrow-circle-right"></i>
            	</a>
          	</div>
        
        </div>

        <div class="col-lg-3 col-xs-6">

            <div class="small-box bg-blue">
              <div class="inner">
                  <h3><?php echo e(Setting::get('currency')); ?> <?php echo e($total); ?></h3>
                  <p><?php echo e(tr('total_revenue')); ?></p>
              </div>
              
              <div class="icon">
                  <i class="fa fa-money"></i>
              </div>

              <a target="_blank" href="<?php echo e(route('moderator.revenues')); ?>" class="small-box-footer">
                  <?php echo e(tr('more_info')); ?>

                  <i class="fa fa-arrow-circle-right"></i>
              </a>
            </div>
        
        </div>

        <div class="col-lg-3 col-xs-6">

            <div class="small-box bg-green">
              <div class="inner">
                  <h3><?php echo e(Setting::get('currency')); ?> <?php echo e($redeem_amount); ?></h3>
                  <p><?php echo e(tr('watch_count_revenue')); ?></p>
              </div>
              
              <div class="icon">
                  <i class="fa fa-money"></i>
              </div>

              <a target="_blank" href="<?php echo e(route('moderator.revenues')); ?>" class="small-box-footer">
                  <?php echo e(tr('more_info')); ?>

                  <i class="fa fa-arrow-circle-right"></i>
              </a>
            </div>
        
        </div>


        <div class="col-lg-3 col-xs-6">

            <div class="small-box bg-red">
              <div class="inner">
                  <h3><?php echo e(Setting::get('currency')); ?> <?php echo e($video_payment); ?></h3>
                  <p><?php echo e(tr('ppv_revenue')); ?></p>
              </div>
              
              <div class="icon">
                  <i class="fa fa-money"></i>
              </div>

              <a target="_blank" href="<?php echo e(route('moderator.user.video-payments')); ?>" class="small-box-footer">
                  <?php echo e(tr('more_info')); ?>

                  <i class="fa fa-arrow-circle-right"></i>
              </a>
            </div>
        
        </div>

	</div>


<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.moderator', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>