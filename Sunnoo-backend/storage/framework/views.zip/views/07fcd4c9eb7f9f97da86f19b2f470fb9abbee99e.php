<?php $__env->startSection('title', tr('view_video')); ?>


<?php $__env->startSection('content-header'); ?> 

<?php echo e(tr('view_video')); ?> 

<a href="#" id="help-popover" class="btn btn-danger" style="font-size: 14px;font-weight: 600" title="Any Help ?">HELP ?</a>

<div id="help-content" style="display: none">

    <ul class="popover-list">
        <li><b><?php echo e(tr('redeems')); ?> - </b><?php echo e(tr('moderator_earnings')); ?></li>
        <li><b><?php echo e(tr('viewers_cnt')); ?> - </b><?php echo e(tr('total_watch_count')); ?> </li>
        <li><b><?php echo e(tr('ppv_created_by')); ?> - </b><?php echo e(tr('admin_moderator_names')); ?> </li>
    </ul>
    
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>

<style>
hr {
    margin-bottom: 10px;
    margin-top: 10px;
}

.ppv-amount-label  {

    font-size: 16px; 

}
.ppv-amount-label label {
    padding: 8px 15px;
}

</style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li><a href="<?php echo e(route('admin.dashboard')); ?>"><i class="fa fa-dashboard"></i><?php echo e(tr('home')); ?></a></li>
    <li><a href="<?php echo e(route('admin.videos')); ?>"><i class="fa fa-video-camera"></i> <?php echo e(tr('videos')); ?></a></li>
    <li class="active"><?php echo e(tr('video')); ?></li>
<?php $__env->stopSection(); ?> 

<?php $__env->startSection('content'); ?>

    <?php $url = $trailer_url = ""; ?>

    <div class="row">

        <?php echo $__env->make('notification.notify', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div class="col-lg-12">
            <div class="box box-primary">
                <div class="box-header with-border">
                    <div class='pull-left'>
                        <h3 class="box-title"> <b><?php echo e($video->title); ?></b></h3>
                        <br>
                        <span style="margin-left:0px" class="description"><?php echo e(tr('created_time')); ?>- <?php echo e($video->video_date); ?></span>
                    </div>
                    <div class='pull-right'>
                        <?php if($video->compress_status == 0 || $video->trailer_compress_status == 0): ?> <span class="label label-danger"><?php echo e(tr('compress')); ?></span>
                        <?php else: ?>
                        <a href="<?php echo e(route('admin.edit.video' , array('id' => $video->video_id))); ?>" class="btn btn-sm btn-warning"><i class="fa fa-pencil"></i> <?php echo e(tr('edit')); ?></a>
                        <?php endif; ?>
                    </div>

                    <div class="clearfix"></div>
                </div>
                <!-- /.box-header -->

                <div class="box-body">

                    <section id="revenue-section" >

                        <div class="row">

                            <h3 style="margin-top:0;" class="text-green col-lg-12"><?php echo e(tr('ppv_revenue')); ?></h3>

                            <div class="col-md-4">

                                <p class="ppv-amount-label">
                                    <b><?php echo e(tr('total')); ?>: </b>
                                    <label class="text-red"><?php echo e(Setting::get('currency')); ?> <?php echo e($video->admin_amount + $video->user_amount); ?></label>
                                </p>

                            </div>

                            <div class="col-md-4">

                                <p class="ppv-amount-label">
                                    <b><?php echo e(tr('admin_amount')); ?>: </b>
                                    <label class="text-green"><?php echo e(Setting::get('currency')); ?> <?php echo e($video->admin_amount); ?></label>
                                </p>

                            </div>

                            <div class="col-md-4">

                                <p class="ppv-amount-label">
                                    <b><?php echo e(tr('moderator_amount')); ?>: </b>
                                    <label class="text-blue">
                                        <?php echo e(Setting::get('currency')); ?> <?php echo e($video->user_amount); ?>

                                    </label>
                                </p>

                            </div>

                        </div>

                        <hr>

                    </section>

                    <section id="video-details-with-images">

                        <div class="row">

                          <div class="col-lg-12 row">

                            <div class="col-lg-4">

                                <div class="box-body box-profile">

                                    <h4><?php echo e(tr('details')); ?></h4>

                                    <ul class="list-group list-group-unbordered">
                                        <li class="list-group-item">
                                          <b><i class="fa fa-suitcase margin-r-5"></i><?php echo e(tr('category')); ?></b> <a class="pull-right"><?php echo e($video->category_name); ?></a>
                                        </li>
                                        <li class="list-group-item">
                                          <b><i class="fa fa-suitcase margin-r-5"></i><?php echo e(tr('sub_category')); ?></b> <a class="pull-right"><?php echo e($video->sub_category_name); ?></a>
                                        </li>
                                        <li class="list-group-item">
                                          <b><i class="fa fa-video-camera margin-r-5"></i><?php echo e(tr('video_type')); ?></b> <a class="pull-right">
                                            <?php if($video->video_type == 1): ?>
                                                <?php echo e(tr('video_upload_link')); ?>

                                            <?php endif; ?>
                                            <?php if($video->video_type == 2): ?>
                                                <?php echo e(tr('youtube')); ?>

                                            <?php endif; ?>
                                            <?php if($video->video_type == 3): ?>
                                                <?php echo e(tr('other_link')); ?>

                                            <?php endif; ?>
                                            </a>
                                        </li>
                                        <?php if($video->video_upload_type == 1 || $video->video_upload_type == 2): ?>
                                        <li class="list-group-item">
                                          <b><i class="fa fa-video-camera margin-r-5"></i><?php echo e(tr('video_upload_type')); ?></b> <a class="pull-right"> 
                                                <?php if($video->video_upload_type == 1): ?>
                                                    <?php echo e(tr('s3')); ?>

                                                <?php endif; ?>
                                                <?php if($video->video_upload_type == 2): ?>
                                                    <?php echo e(tr('direct')); ?>

                                                <?php endif; ?> 
                                            </a>
                                        </li>
                                        <?php endif; ?>
                                        <li class="list-group-item">
                                          <b><i class="fa fa-clock-o margin-r-5"></i><?php echo e(tr('duration')); ?></b> <a class="pull-right"><?php echo e($video->duration); ?></a>
                                        </li>
                                        <li class="list-group-item">
                                          <b><i class="fa fa-star margin-r-5"></i><?php echo e(tr('ratings')); ?></b> <a class="pull-right">
                                              <span class="starRating-view">
                                                <input id="rating5" type="radio" name="ratings" value="5" <?php if($video->ratings == 5): ?> checked <?php endif; ?>>
                                                <label for="rating5">5</label>

                                                <input id="rating4" type="radio" name="ratings" value="4" <?php if($video->ratings == 4): ?> checked <?php endif; ?>>
                                                <label for="rating4">4</label>

                                                <input id="rating3" type="radio" name="ratings" value="3" <?php if($video->ratings == 3): ?> checked <?php endif; ?>>
                                                <label for="rating3">3</label>

                                                <input id="rating2" type="radio" name="ratings" value="2" <?php if($video->ratings == 2): ?> checked <?php endif; ?>>
                                                <label for="rating2">2</label>

                                                <input id="rating1" type="radio" name="ratings" value="1" <?php if($video->ratings == 1): ?> checked <?php endif; ?>>
                                                <label for="rating1">1</label>
                                            </span>
                                          </a>
                                        </li>

                                        <li class="list-group-item">
                                          <b><i class="fa fa-eye margin-r-5"></i><?php echo e(tr('viewers_cnt')); ?></b> <a class="pull-right"><?php echo e($video->watch_count ? number_format_short($video->watch_count) : 0); ?></a>
                                        </li>

                                        <li class="list-group-item">
                                          <b><i class="fa fa-money margin-r-5"></i><?php echo e(tr('redeems')); ?></b> <a class="pull-right"><?php echo e(Setting::get('currency')); ?> <?php echo e($video->redeem_amount ? $video->redeem_amount : 0); ?></a>
                                        </li>

                                        <li class="list-group-item">

                                            <b><i class="fa fa-upload margin-r-5"></i><?php echo e(tr('uploaded_by')); ?></b>
                                            
                                            <?php if(is_numeric($video->uploaded_by)): ?>

                                                <a class="pull-right" href="<?php echo e(route('admin.moderator.view',$video->uploaded_by)); ?>"><?php echo e($video->moderator ? $video->moderator->name : ''); ?></a>


                                            <?php else: ?> 

                                                <a class="pull-right"><?php echo e($video->uploaded_by); ?></a>

                                            <?php endif; ?>
                                            

                                        </li>

                                        <li class="list-group-item">

                                            <b><i class="fa fa-upload margin-r-5"></i><?php echo e(tr('ppv_created_by')); ?></b>

                                            <?php if(is_numeric($video->ppv_created_by)): ?>

                                                <a class="pull-right" href="<?php echo e(route('admin.moderator.view',$video->ppv_created_by)); ?>">
                                                    <?php echo e(moderator_details($video->ppv_created_by , 'name')); ?>

                                                </a>


                                            <?php else: ?> 

                                                <a class="pull-right"><?php echo e($video->ppv_created_by); ?></a>

                                            <?php endif; ?>

                                        </li>

                                                
                                        <li class="list-group-item">
                                            <b><i class="fa fa-thumbs-up margin-r-5"></i><?php echo e(tr('likes')); ?></b> <a class="pull-right"><?php echo e(number_format_short($video->getScopeLikeCount->count())); ?>&nbsp;</a>
                                        </li> 

                                        <li class="list-group-item">
                                            <b><i class="fa fa-thumbs-down margin-r-5"></i><?php echo e(tr('dislikes')); ?></b> <a class="pull-right"><?php echo e(number_format_short($video->getScopeDisLikeCount->count())); ?>&nbsp;</a>
                                        </li> 

                                        <li class="list-group-item">
                                            <b><i class="fa fa-male margin-r-5"></i><?php echo e(tr('age')); ?></b> <a class="pull-right"><?php echo e($video->age); ?>&nbsp;</a>
                                        </li>    
                                    
                                    </ul>
                                </div>

                            </div>

                            <div class="col-lg-8">
                                <strong><i class="fa fa-file-picture-o margin-r-5"></i> <?php echo e(tr('images')); ?></strong>

                                <div class="row margin-bottom" style="margin-top: 10px;">
                                    <div class="col-lg-6">
                                      <img alt="Photo" src="<?php echo e(isset($video->default_image) ? $video->default_image : ''); ?>" class="img-responsive" style="width:100%;height:250px;">
                                    </div>
                                    <!-- /.col -->
                                    <div class="col-lg-6">
                                      <div class="row">
                                         <?php foreach($video_images as $i => $image): ?>
                                        <div class="col-lg-6">
                                          <img alt="Photo" src="<?php echo e($image->image); ?>" class="img-responsive" style="width:100%;height:130px">
                                          <br>
                                        </div>
                                        <?php endforeach; ?>
                                        <?php if($video->is_banner): ?> 
                                            <img alt="Photo" src="<?php echo e($video->banner_image); ?>" class="img-responsive" style="width:100%;height:130px">
                                        <?php endif; ?>
                                        <!-- /.col -->
                                      </div>
                                    </div>
                                      <!-- /.row -->
                                </div>

                            </div>
                            
                          </div>

                        </div>

                        <hr>

                    </section>

                    <section id="description-and-reviews">

                        <div class="row">
                            <div class="col-lg-12">
                                
                                <div class="col-lg-6">
                                      <strong><i class="fa fa-file-text-o margin-r-5"></i> <?php echo e(tr('description')); ?></strong>

                                      <p style="margin-top: 10px;"><?php echo e($video->description); ?>.</p>
                                
                                </div>
                                
                                <div class="col-lg-6">
                                      <strong><i class="fa fa-file-text-o margin-r-5"></i> <?php echo e(tr('reviews')); ?></strong>

                                      <p style="margin-top: 10px;"><?php echo e($video->reviews); ?>.</p>
                                
                                </div>

                            </div>
                        </div>

                        <hr>

                    </section>

                    <section id="video-detailed-description">

                        <?php if($video->details): ?>

                        <div class="col-lg-12">

                            <strong><i class="fa fa-file-text-o margin-r-5"></i> <?php echo e(tr('details')); ?></strong>

                            <p style="margin-top: 10px;"><?= $video->details ?></p>
                        </div>

                        <hr>

                        <?php endif; ?>

                    </section>

                    <section id="ppv-details">

                        <?php if(Setting::get('is_payper_view')): ?>

                            <?php if($video->amount > 0): ?>


                                <h4 style="margin-left: 15px;font-weight: bold;"><?php echo e(tr('pay_per_view')); ?></h4>

                                <div class="row">

                                    <div class="col-lg-12">
                                        <div class="col-lg-4">
                                            <strong><i class="fa fa-file-text-o margin-r-5"></i> <?php echo e(tr('type_of_user')); ?></strong>

                                            <p style="margin-top: 10px;">
                                                <?php if($video->type_of_user == NORMAL_USER): ?>
                                                    <?php echo e(tr('normal_user')); ?>

                                                <?php elseif($video->type_of_user == PAID_USER): ?>
                                                    <?php echo e(tr('paid_user')); ?>

                                                <?php elseif($video->type_of_user == BOTH_USERS): ?> 
                                                    <?php echo e(tr('both_user')); ?>

                                                <?php else: ?>
                                                    -
                                                <?php endif; ?>
                                            </p>
                                        </div>
                                        <div class="col-lg-4">
                                            <strong><i class="fa fa-file-text-o margin-r-5"></i> <?php echo e(tr('type_of_subscription')); ?></strong>

                                            <p style="margin-top: 10px;">
                                                <?php if($video->type_of_subscription == ONE_TIME_PAYMENT): ?>
                                                    <?php echo e(tr('one_time_payment')); ?>

                                                <?php elseif($video->type_of_subscription == RECURRING_PAYMENT): ?>
                                                    <?php echo e(tr('recurring_payment')); ?>

                                                <?php else: ?>
                                                    -
                                                <?php endif; ?>
                                            </p>
                                        </div>
                                        <div class="col-lg-4">
                                            <strong><i class="fa fa-file-text-o margin-r-5"></i> <?php echo e(tr('amount')); ?></strong>

                                            <p style="margin-top: 10px;">
                                               <?php echo e(Setting::get('currency')); ?> <?php echo e($video->amount); ?>

                                            </p>
                                        </div>
                                    </div>
                                
                                </div>

                                <hr>
                            <?php endif; ?>

                        <?php endif; ?>

                    </section>

                    <section id="video-player-section">
                  
                        <div class="row">
                            
                            <div class="col-lg-12">

                                <?php if($video->trailer_video): ?>
                               <div class="col-lg-6">

                                    <strong><i class="fa fa-video-camera margin-r-5"></i> <?php echo e(tr('trailer_video')); ?></strong>

                                
                                    <br>

                                     <br>

                                    <!-- <b><?php echo e(tr('embed_link')); ?> : </b> <a href="<?php echo e(route('embed_video', array('v_t'=>1, 'u_id'=>$video->unique_id))); ?>" target="_blank"><?php echo e(route('embed_video', array('v_t'=>1, 'u_id'=>$video->unique_id))); ?></a> -->

                                    <div class="clearfix"></div>

                                     <br>

                                      <div class="image" id="trailer_video_setup_error" style="display:none">
                                        <img src="<?php echo e(asset('error.jpg')); ?>" alt="<?php echo e(Setting::get('site_name')); ?>" style="width: 100%">
                                    </div>

                                      
                                    <div class="">
                                        <?php if($video->video_upload_type == 1): ?>
                                        <?php $trailer_url = $video->trailer_video; ?>
                                            <div id="trailer-video-player"></div>
                                        <?php else: ?>

                                            <?php if(check_valid_url($video->trailer_video)): ?>

                                                <?php $trailer_url = (Setting::get('streaming_url')) ? Setting::get('streaming_url').get_video_end($video->trailer_video) : $video->trailer_video; ?>

                                                <div id="trailer-video-player"></div>

                                            <?php else: ?>
                                                <div class="image">
                                                    <img src="<?php echo e(asset('error.jpg')); ?>" alt="<?php echo e(Setting::get('site_name')); ?>" style="width: 100%">
                                                </div>
                                            <?php endif; ?>

                                        <?php endif; ?>
                                    </div>
                                    <div class="embed-responsive embed-responsive-16by9" id="flash_error_display_trailer" style="display: none;">
                                       <div style="width: 100%;background: black; color:#fff;height:350px;">
                                             <div style="text-align: center;padding-top:25%"><?php echo e(tr('flash_miss_error')); ?> <a target="_blank" href="http://get.adobe.com/flashplayer/" class="underline"><?php echo e(tr('adobe')); ?></a>.</div>
                                       </div>
                                    </div>
                                </div>
                                <?php endif; ?>
                                <div class="col-lg-6">

                                    <strong><i class="fa fa-video-camera margin-r-5"></i> <?php echo e(tr('full_video')); ?></strong>

                                    <br>

                                    <br>

                                    <!-- <b><?php echo e(tr('embed_link')); ?> : </b> <a href="<?php echo e(route('embed_video', array('v_t'=>2, 'u_id'=>$video->unique_id))); ?>" target="_blank"><?php echo e(route('embed_video', array('v_t'=>2, 'u_id'=>$video->unique_id))); ?></a> -->

                                    <div class="clearfix"></div>

                                    <br>

                                    <div class="image" id="main_video_setup_error" style="display:none">
                                        <img src="<?php echo e(asset('error.jpg')); ?>" alt="<?php echo e(Setting::get('site_name')); ?>" style="width: 100%">
                                    </div>

                                    <div class="">
                                            <?php if($video->video_upload_type == 1): ?>
                                            <?php $url = $video->video; ?>
                                            <div id="main-video-player"></div>
                                        <?php else: ?>
                                            <?php if(check_valid_url($video->video)): ?>

                                                <?php $url = (Setting::get('streaming_url')) ? Setting::get('streaming_url').get_video_end($video->video) : $video->video; ?>
                                                <div id="main-video-player"></div>
                                            <?php else: ?>
                                                <div class="image">
                                                    <img src="<?php echo e(asset('error.jpg')); ?>" alt="<?php echo e(Setting::get('site_name')); ?>" style="width: 100%">
                                                </div>
                                            <?php endif; ?>

                                        <?php endif; ?>
                                    </div>
                                    <div class="embed-responsive embed-responsive-16by9" id="flash_error_display_main" style="display: none;">
                                       <div style="width: 100%;background: black; color:#fff;height:350px;">
                                             <div style="text-align: center;padding-top:25%"><?php echo e(tr('flash_miss_error')); ?> <a target="_blank" href="http://get.adobe.com/flashplayer/" class="underline"><?php echo e(tr('adobe')); ?></a>.</div>
                                       </div>
                                    </div>
                                </div>
                            
                            </div>
                        
                        </div>

                    </section>

                <!-- /.box-body -->
                </div>
            </div>
        </div>
    
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    
    <script src="<?php echo e(asset('jwplayer/jwplayer.js')); ?>"></script>

    <script>jwplayer.key="<?php echo e(Setting::get('JWPLAYER_KEY')); ?>";</script>

    <script type="text/javascript">

        $(document).ready(function(){
            $('#help-popover').popover({
                html : true, 
                content: function() {
                    return $('#help-content').html();
                } 
            });  
        });
        
        jQuery(document).ready(function(){

                  var is_mobile = false;

                  var isMobile = {
                      Android: function() {
                          return navigator.userAgent.match(/Android/i);
                      },
                      BlackBerry: function() {
                          return navigator.userAgent.match(/BlackBerry/i);
                      },
                      iOS: function() {
                          return navigator.userAgent.match(/iPhone|iPad|iPod/i);
                      },
                      Opera: function() {
                          return navigator.userAgent.match(/Opera Mini/i);
                      },
                      Windows: function() {
                          return navigator.userAgent.match(/IEMobile/i);
                      },
                      any: function() {
                          return (isMobile.Android() || isMobile.BlackBerry() || isMobile.iOS() || isMobile.Opera() || isMobile.Windows());
                      }
                  };


                  function getBrowser() {

                      // Opera 8.0+
                      var isOpera = (!!window.opr && !!opr.addons) || !!window.opera || navigator.userAgent.indexOf(' OPR/') >= 0;

                      // Firefox 1.0+
                      var isFirefox = typeof InstallTrigger !== 'undefined';

                      // Safari 3.0+ "[object HTMLElementConstructor]" 
                      var isSafari = /constructor/i.test(window.HTMLElement) || (function (p) { return p.toString() === "[object SafariRemoteNotification]"; })(!window['safari'] || safari.pushNotification);

                      // Internet Explorer 6-11
                      var isIE = /*@cc_on!@*/false || !!document.documentMode;

                      // Edge 20+
                      var isEdge = !isIE && !!window.StyleMedia;

                      // Chrome 1+
                      var isChrome = !!window.chrome && !!window.chrome.webstore;

                      // Blink engine detection
                      var isBlink = (isChrome || isOpera) && !!window.CSS;

                      var b_n = '';

                      switch(true) {

                          case isFirefox :

                                  b_n = "Firefox";

                                  break;
                          case isChrome :

                                  b_n = "Chrome";

                                  break;

                          case isSafari :

                                  b_n = "Safari";

                                  break;
                          case isOpera :

                                  b_n = "Opera";

                                  break;

                          case isIE :

                                  b_n = "IE";

                                  break;

                          case isEdge : 

                                  b_n = "Edge";

                                  break;

                          case isBlink : 

                                  b_n = "Blink";

                                  break;

                          default :

                                  b_n = "Unknown";

                                  break;

                      }

                      return b_n;

                  }


                  if(isMobile.any()) {

                      var is_mobile = true;

                  }


                  var browser = getBrowser();


                  if ((browser == 'Safari') || (browser == 'Opera') || is_mobile) {

                    var video = "<?php echo e($ios_video); ?>";

                    var trailer_video = "<?php echo e($ios_trailer_video); ?>";

                  } else {

                    var video = "<?php echo e($videoStreamUrl); ?>";

                    var trailer_video = "<?php echo e($trailerstreamUrl); ?>";

                  }

                console.log("Video " +video);
                    
                console.log("Trailer "+trailer_video);

                <?php if($url): ?>

                    var playerInstance = jwplayer("main-video-player");


                    <?php if($videoStreamUrl || $ios_video): ?> 

                        playerInstance.setup({
                            file: video,
                            image: "<?php echo e($video->default_image); ?>",
                            width: "100%",
                            aspectratio: "16:9",
                            primary: "flash",
                            controls : true,
                            "controlbar.idlehide" : false,
                            controlBarMode:'floating',
                            "controls": {
                              "enableFullscreen": false,
                              "enablePlay": false,
                              "enablePause": false,
                              "enableMute": true,
                              "enableVolume": true
                            },
                            // autostart : true,
                            "sharing": {
                                "sites": ["reddit","facebook","twitter"]
                              },

                           tracks : [{
                              file : "<?php echo e($video->video_subtitle); ?>",
                              kind : "captions",
                              default : true,
                            }]
                        });
                    <?php else: ?> 
                        var videoPath = "<?php echo e($videoPath); ?>";
                        var videoPixels = "<?php echo e($video_pixels); ?>";

                        var path = [];

                        var splitVideo = videoPath.split(',');

                        var splitVideoPixel = videoPixels.split(',');


                        for (var i = 0 ; i < splitVideo.length; i++) {
                            path.push({file : splitVideo[i], label : splitVideoPixel[i]});
                        }
                        playerInstance.setup({
                            sources: path,
                            image: "<?php echo e($video->default_image); ?>",
                            width: "100%",
                            aspectratio: "16:9",
                            primary: "flash",
                            controls : true,
                            "controlbar.idlehide" : false,
                            controlBarMode:'floating',
                            "controls": {
                              "enableFullscreen": false,
                              "enablePlay": false,
                              "enablePause": false,
                              "enableMute": true,
                              "enableVolume": true
                            },
                            // autostart : true,
                            "sharing": {
                                "sites": ["reddit","facebook","twitter"]
                              },

                              tracks : [{
                              file : "<?php echo e($video->video_subtitle); ?>",
                              kind : "captions",
                              default : true,
                            }]
                        });

                        
                    
                    <?php endif; ?>

                    playerInstance.on('setupError', function() {

                                jQuery("#main-video-player").css("display", "none");
                               // jQuery('#trailer_video_setup_error').hide();
                               

                                var hasFlash = false;
                                try {
                                    var fo = new ActiveXObject('ShockwaveFlash.ShockwaveFlash');
                                    if (fo) {
                                        hasFlash = true;
                                    }
                                } catch (e) {
                                    if (navigator.mimeTypes
                                            && navigator.mimeTypes['application/x-shockwave-flash'] != undefined
                                            && navigator.mimeTypes['application/x-shockwave-flash'].enabledPlugin) {
                                        hasFlash = true;
                                    }
                                }

                                if (hasFlash == false) {
                                    jQuery('#flash_error_display_main').show();
                                    return false;
                                }

                                jQuery('#main_video_setup_error').css("display", "block");

                               // confirm('The video format is not supported in this browser. Please option some other browser.');

                            });

                <?php endif; ?>

                <?php if($trailer_url): ?>

                    var playerInstance = jwplayer("trailer-video-player");

                    <?php if($trailerstreamUrl || $ios_trailer_video): ?>

                            playerInstance.setup({
                                file : trailer_video,
                                image: "<?php echo e($video->default_image); ?>",
                                width: "100%",

                                aspectratio: "16:9",
                                primary: "flash",
                                 tracks : [{
                                file : "<?php echo e($video->trailer_subtitle); ?>",
                                kind : "captions",
                                default : true,
                              }]
                            });

                    <?php else: ?>

                            var trailerVideoPath = "<?php echo e($trailer_video_path); ?>";
                            var trailerVideoPixels = "<?php echo e($trailer_pixels); ?>";

                            var trailerPath = [];

                            var splitTrailer = trailerVideoPath.split(',');

                            var splitTrailerPixel = trailerVideoPixels.split(',');


                            for (var i = 0 ; i < splitTrailer.length; i++) {

                                trailerPath.push({file : splitTrailer[i], label : splitTrailerPixel[i]});
                            }

                            playerInstance.setup({
                                sources : trailerPath,
                                image: "<?php echo e($video->default_image); ?>",
                                width: "100%",

                                aspectratio: "16:9",
                                primary: "flash",
                                 tracks : [{
                                  file : "<?php echo e($video->trailer_subtitle); ?>",
                                  kind : "captions",
                                  default : true,
                                }]
                            });

                    <?php endif; ?>

                    playerInstance.on('setupError', function() {

                                jQuery("#trailer-video-player").css("display", "none");
                               // jQuery('#trailer_video_setup_error').hide();
                               

                                var hasFlash = false;
                                try {
                                    var fo = new ActiveXObject('ShockwaveFlash.ShockwaveFlash');
                                    if (fo) {
                                        hasFlash = true;
                                    }
                                } catch (e) {
                                    if (navigator.mimeTypes
                                            && navigator.mimeTypes['application/x-shockwave-flash'] != undefined
                                            && navigator.mimeTypes['application/x-shockwave-flash'].enabledPlugin) {
                                        hasFlash = true;
                                    }
                                }

                                if (hasFlash == false) {
                                    jQuery('#flash_error_display_trailer').show();
                                    return false;
                                }

                                jQuery('#trailer_video_setup_error').css("display", "block");

                               // confirm('The video format is not supported in this browser. Please option some other browser.');
                            
                            });
                <?php endif; ?>
        });

    </script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>