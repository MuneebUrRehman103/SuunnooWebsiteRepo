<?php $__env->startSection('title', tr('users')); ?>

<?php $__env->startSection('content-header'); ?> 

<?php echo e(tr('users')); ?> 

<a href="#" id="help-popover" class="btn btn-danger" style="font-size: 14px;font-weight: 600" title="<?php echo e(tr('any_help')); ?>"><?php echo e(tr('help_ques_mark')); ?></a>

<div id="help-content" style="display: none">

    <ul class="popover-list">
        <li><span class="text-green"><i class="fa fa-check-circle"></i></span> - <?php echo e(tr('paid_subscribed_users')); ?></li>
        <li><span class="text-red"><i class="fa fa-times"></i></span> -<?php echo e(tr('unpaid_unsubscribed_user')); ?></li>
        <li><b><?php echo e(tr('validity_days')); ?> - </b><?php echo e(tr('expiry_days_subscription_user')); ?></li>
        <li><b><?php echo e(tr('upgrade')); ?> - </b><?php echo e(tr('admin_moderator_upgrade_option')); ?></li>
    </ul>
    
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <li><a href="<?php echo e(route('admin.dashboard')); ?>"><i class="fa fa-dashboard"></i><?php echo e(tr('home')); ?></a></li>
    <li class="active"><i class="fa fa-user"></i> <?php echo e(tr('users')); ?></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

	<?php echo $__env->make('notification.notify', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<div class="row">
        <div class="col-xs-12">
          <div class="box box-primary">
          	<div class="box-header label-primary">
                <b style="font-size:18px;"><?php echo e(tr('users')); ?></b>
                <a href="<?php echo e(route('admin.add.user')); ?>" class="btn btn-default pull-right"><?php echo e(tr('add_user')); ?></a>
            </div>
            <div class="box-body">

            	<?php if(count($users) > 0): ?>

	              	<table id="example1" class="table table-bordered table-striped">

						<thead>
						    <tr>
								<th><?php echo e(tr('id')); ?></th>
								<th><?php echo e(tr('username')); ?></th>
								<th><?php echo e(tr('email')); ?></th>
								<th><?php echo e(tr('upgrade')); ?></th>
								<th><?php echo e(tr('validity_days')); ?></th>
								<th><?php echo e(tr('active_plan')); ?></th>
								<th><?php echo e(tr('sub_profiles')); ?></th>
								<th><?php echo e(tr('status')); ?></th>
								<th><?php echo e(tr('action')); ?></th>
						    </tr>
						</thead>

						<tbody>
							<?php foreach($users as $i => $user): ?>

							    <tr>
							      	<td><?php echo e($i+1); ?></td>
							      	<td>
							      		<a href="<?php echo e(route('admin.view.user' , $user->id)); ?>">
							      			<?php echo e($user->name); ?>


							      			<?php if($user->user_type): ?>

							      				<span class="text-green pull-right"><i class="fa fa-check-circle"></i></span>

							      			<?php else: ?>

							      				<span class="text-red pull-right"><i class="fa fa-times"></i></span>

							      			<?php endif; ?>
							      		</a>
							      	</td>

							      	<td><?php echo e($user->email); ?></td>
							      	
							      	<td>
							      		<?php if($user->is_moderator): ?>
							      			<a onclick="return confirm('Are you sure?');" href="<?php echo e(route('user.upgrade.disable' , array('id' => $user->id, 'moderator_id' => $user->moderator_id))); ?>" class="label label-warning" title="Do you want to remove the user from Moderator Role?"><?php echo e(tr('disable')); ?></a>
							      		<?php else: ?>
							      			<a onclick="return confirm('Are you sure?');" href="<?php echo e(route('admin.user.upgrade' , array('id' => $user->id ))); ?>" class="label label-danger" title="Do you want to change the user as Moderator ?"><?php echo e(tr('upgrade')); ?></a>
							      		<?php endif; ?>

							      	</td>
							      
							      	<td>
								      	<?php if($user->user_type): ?>
	                                        <?php echo e(get_expiry_days($user->id)); ?>

	                                    <?php endif; ?>
							      	</td>

							      	<td><?php echo active_plan($user->id);?></td>


							      	<td>
							      		<a role="menuitem" tabindex="-1" href="<?php echo e(route('admin.view.sub_profiles',  $user->id)); ?>"><span class="label label-primary">
							      			<?php echo e(count($user->subProfile)); ?> <?php echo e(tr('sub_profiles')); ?></span>
							      		</a>
							      	</td>

							      	<td>
								      	<?php if($user->is_activated): ?>

								      		<span class="label label-success"><?php echo e(tr('approve')); ?></span>

								      	<?php else: ?>

								      		<span class="label label-warning"><?php echo e(tr('pending')); ?></span>

								      	<?php endif; ?>

							     	</td>
							 
							      	<td>
            							<ul class="admin-action btn btn-default">
            								<li class="<?php if($i < 2): ?> dropdown <?php else: ?> dropup <?php endif; ?>">
								                <a class="dropdown-toggle" data-toggle="dropdown" href="#">
								                  <?php echo e(tr('action')); ?> <span class="caret"></span>
								                </a>
								                <ul class="dropdown-menu">
								                  	<li role="presentation"><a role="menuitem" tabindex="-1" href="<?php echo e(route('admin.edit.user' , array('id' => $user->id))); ?>"><?php echo e(tr('edit')); ?></a></li>

								                  	<li role="presentation"><a role="menuitem" tabindex="-1" href="<?php echo e(route('admin.view.user' , $user->id)); ?>"><?php echo e(tr('view')); ?></a></li>
								                  	
								                  	<li role="presentation"><a role="menuitem" tabindex="-1" href="<?php echo e(route('admin.user_approve' , array('id'=>$user->id))); ?>"><?php if($user->is_activated): ?> <?php echo e(tr('decline')); ?> <?php else: ?> <?php echo e(tr('approve')); ?> <?php endif; ?></a></li>

								                  	<?php if(!$user->is_verified): ?>
								                  	
									                  	<li role="presentation" class="divider"></li>								                  	
											      		<li role="presentation">
									                  		<a role="menuitem" tabindex="-1" href="<?php echo e(route('admin.users.verify' , $user->id)); ?>"><?php echo e(tr('verify')); ?></a>
								                  		</li>
										      		<?php endif; ?>

								                  	<li role="presentation" class="divider"></li>

								                  	<li role="presentation">
								                  		<a role="menuitem" tabindex="-1" href="<?php echo e(route('admin.view.sub_profiles',  $user->id)); ?>"><?php echo e(tr('sub_profiles')); ?></a>
								                  	</li>

								                  	<li role="presentation">
								                  	 	<?php if(Setting::get('admin_delete_control')): ?>
								                  	 		<a role="button" href="javascript:;" class="btn disabled" style="text-align: left"><?php echo e(tr('delete')); ?></a>
								                  	 	<?php elseif(get_expiry_days($user->id) > 0): ?>

								                  	 		<a role="menuitem" tabindex="-1" onclick="return confirm('Are you sure want to delete the premium user?');" href="<?php echo e(route('admin.delete.user', array('id' => $user->id))); ?>"><?php echo e(tr('delete')); ?>

								                  			</a>
								                  		<?php else: ?> 
								                  			<a role="menuitem" tabindex="-1" onclick="return confirm('Are you sure?');" href="<?php echo e(route('admin.delete.user', array('id' => $user->id))); ?>"><?php echo e(tr('delete')); ?>

								                  			</a>
								                  	 	<?php endif; ?>

								                  	</li>
								                  	<li role="presentation" class="divider"></li>

								                  	<?php /*<li role="presentation"><a role="menuitem" tabindex="-1" href="{{route('admin.user.history', $user->id)}}">{{tr('history')}}</a></li>

								                  	<li role="presentation"><a role="menuitem" tabindex="-1" href="{{route('admin.user.wishlist', $user->id)}}">{{tr('wishlist')}}</a></li> */?>
								                  	<li>
														<a href="<?php echo e(route('admin.subscriptions.plans' , $user->id)); ?>">		
															<span class="text-green"><b><i class="fa fa-eye"></i>&nbsp;<?php echo e(tr('subscription_plans')); ?></b></span>
														</a>

													</li>
								                  	

								                </ul>
              								</li>
            							</ul>
							      	
							      	</td>
							    </tr>
							<?php endforeach; ?>
						</tbody>
					</table>
				<?php else: ?>
					<h3 class="no-result"><?php echo e(tr('no_user_found')); ?></h3>
				<?php endif; ?>
            </div>
          </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>