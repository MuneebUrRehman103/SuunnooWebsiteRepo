<?php $__env->startSection('title', tr('edit_subscription')); ?>

<?php $__env->startSection('content-header', tr('edit_subscription')); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li><a href="<?php echo e(route('admin.dashboard')); ?>"><i class="fa fa-dashboard"></i><?php echo e(tr('home')); ?></a></li>
    <li><a href="<?php echo e(route('admin.subscriptions.index')); ?>"><i class="fa fa-key"></i> <?php echo e(tr('subscriptions')); ?></a></li>
    <li class="active"><?php echo e(tr('edit_subscription')); ?></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('notification.notify', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="row">

        <div class="col-md-10 ">

            <div class="box box-primary">

                <div class="box-header label-primary">
                    <b><?php echo e(tr('edit_subscription')); ?></b>
                    <a href="<?php echo e(route('admin.subscriptions.index')); ?>" style="float:right" class="btn btn-default"><?php echo e(tr('view_subscriptions')); ?></a>
                </div>

                <form class="form-horizontal" action="<?php echo e(route('admin.subscriptions.save')); ?>" method="POST" enctype="multipart/form-data" role="form">
                    <input type="hidden" name="id" value="<?php echo e($data->id); ?>">

                    <div class="box-body">

                        <div class="form-group">
                            <label for="title" class="col-sm-2 control-label"><?php echo e(tr('title')); ?></label>

                            <div class="col-sm-10">
                                <input type="text" required name="title" class="form-control" id="title" value="<?php echo e(isset($data) ? $data->title : old('title')); ?>" placeholder="<?php echo e(tr('title')); ?>">
                            </div>
                        </div>

                        <div class="form-group">

                            <label for="description" class="col-sm-2 control-label"><?php echo e(tr('description')); ?></label>

                            <div class="col-sm-10">

                                <textarea class="form-control" name="description" required placeholder="<?php echo e(tr('description')); ?>"><?php echo e(isset($data) ? $data->description : old('description')); ?></textarea>

                            </div>
                        </div>

                        <div class="form-group">
                            <label for="plan" class="col-sm-2 control-label"><?php echo e(tr('no_of_months')); ?></label>

                            <div class="col-sm-10">
                                <input type="number" min="1" max="12" pattern="[0-9][0-2]{2}"  required name="plan" class="form-control" id="plan" value="<?php echo e(isset($data) ? $data->plan : old('plan')); ?>" title="<?php echo e(tr('please_enter_plan_month')); ?>" placeholder="<?php echo e(tr('no_of_months')); ?>">
                            </div>
                        </div>
                         <div class="form-group">

                            <label for="amount" class="col-sm-2 control-label"><?php echo e(tr('no_of_account')); ?></label>

                            <div class="col-sm-10">
                                <input type="text" required name="no_of_account" class="form-control" id="manage_account_count" placeholder="<?php echo e(tr('manage_account_count')); ?>" pattern="[0-9]{1,}" value="<?php echo e($data->no_of_account); ?>">
                            </div>

                        </div>

                        <div class="form-group">
                            <label for="amount" class="col-sm-2 control-label"><?php echo e(tr('amount')); ?></label>

                            <div class="col-sm-10">
                                <input type="number" required value="<?php echo e(isset($data) ? $data->amount : old('amount')); ?>" name="amount" class="form-control" id="amount" placeholder="<?php echo e(tr('amount')); ?>" step="any">
                            </div>
                        </div>

                    </div>

                    <div class="box-footer">
                        <button type="reset" class="btn btn-danger"><?php echo e(tr('cancel')); ?></button>
                        <?php if(Setting::get('admin_delete_control')): ?>
                            <a href="#" class="btn btn-success pull-right" disabled><?php echo e(tr('submit')); ?></a>
                        <?php else: ?>
                            <button type="submit" class="btn btn-success pull-right"><?php echo e(tr('submit')); ?></button>
                        <?php endif; ?>
                    </div>
                </form>
            
            </div>

        </div>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>