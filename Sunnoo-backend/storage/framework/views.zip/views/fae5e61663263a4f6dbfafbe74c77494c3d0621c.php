<?php $__env->startSection('title', tr('edit_user')); ?>

<?php $__env->startSection('content-header', tr('edit_user')); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li><a href="<?php echo e(route('admin.dashboard')); ?>"><i class="fa fa-dashboard"></i><?php echo e(tr('home')); ?></a></li>
    <li><a href="<?php echo e(route('admin.users')); ?>"><i class="fa fa-user"></i> <?php echo e(tr('users')); ?></a></li>
    <li class="active"><?php echo e(tr('edit_user')); ?></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('notification.notify', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="row">

        <div class="col-md-10">

            <div class="box box-primary">

                <div class="box-header label-primary">
                    <b style="font-size:18px;"><?php echo e(tr('edit_user')); ?></b>
                    <a href="<?php echo e(route('admin.add.user')); ?>" class="btn btn-default pull-right"><?php echo e(tr('add_user')); ?></a>
                </div>

                <form class="form-horizontal" action="<?php echo e(route('admin.save.user')); ?>" method="POST" enctype="multipart/form-data" role="form">

                    <div class="box-body">
                        <input type="hidden" name="id" value="<?php echo e($user->id); ?>">

                        <div class="form-group">
                            <label for="email" class="col-sm-1 control-label"><?php echo e(tr('email')); ?></label>
                            <div class="col-sm-10">
                                <input type="email" required class="form-control" value="<?php echo e($user->email); ?>" id="email" name="email" placeholder="<?php echo e(tr('email')); ?>">
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="username" class="col-sm-1 control-label"><?php echo e(tr('username')); ?></label>

                            <div class="col-sm-10">
                                <input type="text" required name="name" value="<?php echo e($user->name); ?>" class="form-control" id="username" placeholder="<?php echo e(tr('name')); ?>">
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="mobile" class="col-sm-1 control-label"><?php echo e(tr('mobile')); ?></label>

                            <div class="col-sm-10">
                                <input type="text" required name="mobile" value="<?php echo e($user->mobile); ?>" class="form-control" id="mobile" placeholder="<?php echo e(tr('mobile')); ?>">
                            </div>
                        </div>

                    </div>

                    <div class="box-footer">
                        <button type="reset" class="btn btn-danger"><?php echo e(tr('cancel')); ?></button>
                        <?php if(Setting::get('admin_delete_control')): ?>
                            <a href="#" class="btn btn-success pull-right" disabled><?php echo e(tr('submit')); ?></a>
                        <?php else: ?>
                            <button type="submit" class="btn btn-success pull-right"><?php echo e(tr('submit')); ?></button>
                        <?php endif; ?>
                    </div>
                    <input type="hidden" name="timezone" value="" id="userTimezone">
                </form>
            
            </div>

        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<script src="<?php echo e(asset('assets/js/jstz.min.js')); ?>"></script>
<script>
    
    $(document).ready(function() {

        var dMin = new Date().getTimezoneOffset();
        var dtz = -(dMin/60);
        // alert(dtz);
        $("#userTimezone").val(jstz.determine().name());
    });

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>