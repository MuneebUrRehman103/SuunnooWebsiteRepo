<?php $__env->startSection('title', tr('sub_categories')); ?>

<?php $__env->startSection('content-header'); ?>

	<span style="color:#1d880c !important"><?php echo e($category->name); ?> </span> - <?php echo e(tr('sub_categories')); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li><a href="<?php echo e(route('admin.dashboard')); ?>"><i class="fa fa-dashboard"></i><?php echo e(tr('home')); ?></a></li>
    <li><a href="<?php echo e(route('admin.categories')); ?>"><i class="fa fa-suitcase"></i> <?php echo e(tr('categories')); ?></a></li>
    <li class="active"><i class="fa fa-suitcase"></i> <?php echo e(tr('sub_categories')); ?></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('notification.notify', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<div class="row">
        <div class="col-xs-12">
          <div class="box box-primary">
          	<div class="box-header label-primary">
                <b style="font-size:18px;"><?php echo e(tr('sub_categories')); ?></b>
                <a href="<?php echo e(route('admin.add.sub_category' , array('category' => $category->id))); ?>" class="btn btn-default pull-right"><?php echo e(tr('add_sub_category')); ?></a>
            </div>
            <div class="box-body">

            	<?php if(count($data) > 0): ?>

	              	<table id="example1" class="table table-bordered table-striped">

						<thead>
						    <tr>
						      <th><?php echo e(tr('id')); ?></th>
						      <th><?php echo e(tr('sub_category')); ?></th>
						      <th><?php echo e(tr('description')); ?></th>
						      <th><?php echo e(tr('status')); ?></th>
						      <?php /*@if($category->is_series)
						      	<th>{{tr('genres')}}</th>
						      @endif */?>
						      <th><?php echo e(tr('image')); ?></th>
						      <th><?php echo e(tr('action')); ?></th>
						    </tr>
						</thead>

						<tbody>

							<?php foreach($data as $i => $sub_category): ?>

								<?php $images = ($sub_category->subCategoryImage != null && !empty($sub_category->subCategoryImage)) ? $sub_category->subCategoryImage : []; ?>

							    <tr>
							      	<td><?php echo e($i+1); ?></td>
							      	<td><?php echo e($sub_category->sub_category_name); ?></td>
							      	<td><?php echo e($sub_category->description); ?></td>

							      	<td>
							      		<?php if($sub_category->is_approved): ?>
							      			<span class="label label-success"><?php echo e(tr('approved')); ?></span>
							       		<?php else: ?>
							       			<span class="label label-warning"><?php echo e(tr('pending')); ?></span>
							       		<?php endif; ?>
							       </td>

							       	<?php /*@if($category->is_series)

								       <td>
								      		<button type="button" class="btn btn-success btn-sm" data-toggle="modal" data-target="#genres{{$i}}">
												{{tr('view_genres')}}
											</button>
								      	</td>

							      	@endif */?>

							      	<td>
							      		<?php if(count($images) > 0): ?>


							                	<?php if($images[0]): ?>
								                    
								                        <img class="img-responsive" src="<?php echo e($images[0]->picture); ?>" alt="SubCategory" style="width: 50px;height: 50px;">
								                    
							                    <?php endif; ?>


						                <?php endif; ?>
							      	</td>

								    <td>
            							<ul class="admin-action btn btn-default">
            								<li class="dropup">
								                <a class="dropdown-toggle" data-toggle="dropdown" href="#">
								                  <?php echo e(tr('action')); ?> <span class="caret"></span>
								                </a>
								                <ul class="dropdown-menu">

								                  	<li role="presentation">
														<?php if(Setting::get('admin_delete_control')): ?>
                                                            <a role="button" href="javascript:;" class="btn disabled" style="text-align: left"><?php echo e(tr('edit')); ?></a>
                                                        <?php else: ?>
															<a role="menuitem" tabindex="-1" href="<?php echo e(route('admin.edit.sub_category' , array('category_id' => $category->id,'sub_category_id' => $sub_category->id))); ?>"><?php echo e(tr('edit')); ?></a></li>
														<?php endif; ?>

								                  	<!-- <li role="presentation"><a role="menuitem" tabindex="-1" href="<?php echo e(route('admin.view.sub_category' , array('sub_category_id' => $sub_category->id))); ?>"><?php echo e(tr('view_sub_category')); ?></a></li> -->


								                  	<li class="divider" role="presentation"></li>

								                  	<?php if($sub_category->is_approved): ?>
								                  		<li role="presentation"><a role="menuitem" tabindex="-1" href="<?php echo e(route('admin.sub_category.approve' , array('id' => $sub_category->id , 'status' =>0))); ?>"><?php echo e(tr('decline')); ?></a></li>
								                  	<?php else: ?>
								                  		<li role="presentation"><a role="menuitem" tabindex="-1" href="<?php echo e(route('admin.sub_category.approve' , array('id' => $sub_category->id , 'status' => 1))); ?>"><?php echo e(tr('approve')); ?></a></li>
								                  	<?php endif; ?>


								                  	<li role="presentation">

								                  		<?php if(Setting::get('admin_delete_control')): ?>

									                  	 	<a role="button" href="javascript:;" class="btn disabled" style="text-align: left"><?php echo e(tr('delete')); ?></a>

									                  	 <?php else: ?>

								                  			<a role="menuitem" onclick="return confirm('Are you sure?')" tabindex="-1" href="<?php echo e(route('admin.delete.sub_category' , array('sub_category_id' => $sub_category->id))); ?>"><?php echo e(tr('delete')); ?></a>
								                  		<?php endif; ?>

								                  	</li>

								                  	<?php if($category->is_series): ?>

								                  	
									                  	<li class="divider" role="presentation"></li>

									                  	<li role="presentation"><a role="menuitem" tabindex="-1" href="<?php echo e(route('admin.add.genre' , array('sub_category' => $sub_category->id))); ?>"><?php echo e(tr('add_genre')); ?></a></li>
									                  	<li role="presentation"><a role="menuitem" tabindex="-1" href="<?php echo e(route('admin.genres' , array('sub_category' => $sub_category->id))); ?>"><?php echo e(tr('view_genres')); ?></a></li>

								                  	<?php endif; ?>
								              
								                </ul>
              								</li>
            							</ul>
								    </td>
							    </tr>



								<!-- Modalfor sub category images -->
								<?php if($category->is_series): ?>

									<div class="modal fade" id="genres<?php echo e($i); ?>" role="dialog">

									    <div class="modal-dialog">
									    	<!-- Modal content-->
									    	<div class="modal-content">

									        	<div class="modal-header">
									          		<button type="button" class="close" data-dismiss="modal">&times;</button>
									          		<h4 class="modal-title"><?php echo e($sub_category->sub_category_name); ?></h4>
									        	</div>

									        	<div class="modal-body">

									        		<?php if(count($sub_category->genres) > 0): ?>

										                <div class="row">

										                	<?php foreach($sub_category->genres as $genre): ?>
										                		<div class="col-lg-12">
											                		<div class="box">
											                			<div class="box-header ui-sortable-handle" style="cursor: move;">

															             	<h3 class="box-title"><?php echo e($genre->name); ?></h3>
															              	<!-- tools box -->
															              	<div class="pull-right box-tools">
															              		<!--<?php if($genre->is_approved): ?>
																              		<a title="Decline" href="<?php echo e(route('admin.genre.approve' , array('id' => $genre->id , 'status' => 0))); ?>" class="btn btn-warning btn-sm">
																                  		<i class="fa fa-times"></i>
																                  	</a>
																	       		<?php else: ?>
																	       			<a title="Approve" href="<?php echo e(route('admin.genre.approve' , array('id' => $genre->id , 'status' => 1))); ?>" class="btn btn-success btn-sm">
																                  		<i class="fa fa-check"></i>
																                  	</a>
																	       		<?php endif; ?> -->

															                	<a title="Delete" href="<?php echo e(route('admin.delete.genre' , $genre->id)); ?>" class="btn btn-danger btn-sm">
															                  		<i class="fa fa-trash"></i>
															                  	</a>
															              	</div>
															              	<!-- /. tools -->
																        </div>
											                		</div>
											                  	</div>
										                    <?php endforeach; ?>

										                </div>

										            <?php else: ?>
										            	<p style="padding: 5px"><?php echo e(tr('no_genre')); ?></p>
									                <?php endif; ?>

									        	</div>

									        	<div class="modal-footer">
									          		<button type="button" class="btn btn-default" data-dismiss="modal"><?php echo e(tr('close')); ?></button>
									        	</div>
									    	</div>

										</div>

									</div>

								<?php endif; ?>

							    <script type="text/javascript">
								    $(function () {
								    	$('#image<?php echo e($i); ?>').on('shown.bs.modal', function () {
											  $('#myInput').focus()
										});
									});
							    </script>

							<?php endforeach; ?>
						</tbody>
					</table>
				<?php else: ?>
					<h3 class="no-result"><?php echo e(tr('no_sub_category_found')); ?></h3>
				<?php endif; ?>
            </div>
          </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>