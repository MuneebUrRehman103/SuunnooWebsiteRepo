<?php $__env->startSection('title', tr('add_page')); ?>

<?php $__env->startSection('content-header', tr('add_page')); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li><a href="<?php echo e(route('admin.dashboard')); ?>"><i class="fa fa-dashboard"></i><?php echo e(tr('home')); ?></a></li>
    <li><a href="<?php echo e(route('static_pages.index')); ?>"><i class="fa fa-book"></i><?php echo e(tr('pages')); ?></a></li>
    <li class="active"><i class="fa fa-book"></i> <?php echo e(tr('add_page')); ?></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('notification.notify', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  	<div class="row">

	    <div class="col-md-10">

	        <div class="box box-primary">

	            <div class="box-header label-primary">
                    <b style="font-size:18px;"><?php echo e(tr('add_page')); ?></b>
                    <a href="<?php echo e(route('static_pages.index')); ?>" class="btn btn-default pull-right"><?php echo e(tr('pages')); ?></a>
                </div>

	            <form  action="<?php echo e(route('static_pages.add.save')); ?>" method="POST" enctype="multipart/form-data" role="form">

	                <div class="box-body">

	                     <div class="form-group floating-label">
	                     	<label for="select2"><?php echo e(tr('select_page_type')); ?></label>
                            <select id="select2" name="type" class="form-control select2">
                                <?php foreach($static_keys as $value): ?> 
	                                <?php if(!in_array($value, $view_pages)): ?>
	                                	<option value="<?php echo e($value); ?>" selected="true"><?php echo e($value); ?></option>
	                                <?php endif; ?>
                                <?php endforeach; ?>
                            </select>
                            
                        </div>

	                    <div class="form-group">
	                        <label for="heading"><?php echo e(tr('heading')); ?></label>
	                        <input type="text" required class="form-control" name="heading" id="heading" placeholder="<?php echo e(tr('enter')); ?> <?php echo e(tr('heading')); ?>">
	                    </div>

	                    <div class="form-group">
	                        <label for="description"><?php echo e(tr('description')); ?></label>

	                        <textarea id="ckeditor" required name="description" class="form-control" placeholder="<?php echo e(tr('enter')); ?> <?php echo e(tr('description')); ?>"></textarea>
	                        
	                    </div>

	                </div>

	              <div class="box-footer">
	                    <button type="reset" class="btn btn-danger"><?php echo e(tr('cancel')); ?></button>
	                    <?php if(Setting::get('admin_delete_control')): ?>
                            <a href="#" class="btn btn-success pull-right" disabled><?php echo e(tr('submit')); ?></a>
                        <?php else: ?>
                            <button type="submit" class="btn btn-success pull-right"><?php echo e(tr('submit')); ?></button>
                        <?php endif; ?>
	              </div>

	            </form>
	        
	        </div>

	    </div>

	</div>
   
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="https://cdn.ckeditor.com/4.5.5/standard/ckeditor.js"></script>
    <script>
        CKEDITOR.replace( 'ckeditor' );
    </script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>