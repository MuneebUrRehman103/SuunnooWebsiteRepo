<?php $__env->startSection('title', tr('view_user')); ?>

<?php $__env->startSection('content-header', tr('view_user')); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li><a href="<?php echo e(route('admin.dashboard')); ?>"><i class="fa fa-dashboard"></i><?php echo e(tr('home')); ?></a></li>
    <li><a href="<?php echo e(route('admin.users')); ?>"><i class="fa fa-user"></i> <?php echo e(tr('users')); ?></a></li>
    <li class="active"><i class="fa fa-user"></i> <?php echo e(tr('view_user')); ?></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

	<style type="text/css">
		.timeline::before {
		    content: '';
		    position: absolute;
		    top: 0;
		    bottom: 0;
		    width: 0;
		    background: #fff;
		    left: 0px;
		    margin: 0;
		    border-radius: 0px;
		}
	</style>

	<div class="row">

		<div class="col-md-6 col-md-offset-3">

    		<div class="box box-widget widget-user-2">

            	<div class="widget-user-header bg-gray">
            		<div class="pull-left">
	              		<div class="widget-user-image">
	                		<img class="img-circle" src="<?php if($user->picture): ?> <?php echo e($user->picture); ?> <?php else: ?> <?php echo e(asset('admin-css/dist/img/avatar.png')); ?> <?php endif; ?>" alt="User Avatar">
	              		</div>

	              		<h3 class="widget-user-username"><?php echo e($user->name); ?> </h3>
	      				<h5 class="widget-user-desc"><?php echo e(tr('user')); ?></h5>
      				</div>
      				<div class="pull-right">
      					<a href="<?php echo e(route('admin.edit.user' , array('id' => $user->id))); ?>" class="btn btn-sm btn-warning"><?php echo e(tr('edit')); ?></a>
      				</div>
      				<div class="clearfix"></div>
            	</div>

            	<div class="box-footer no-padding">
              		<ul class="nav nav-stacked">
		                <li><a href="#"><?php echo e(tr('username')); ?> <span class="pull-right"><?php echo e($user->name); ?></span></a></li>
		                <li><a href="#"><?php echo e(tr('email')); ?> <span class="pull-right"><?php echo e($user->email); ?></span></a></li>
		                <li><a href="#"><?php echo e(tr('mobile')); ?> <span class="pull-right"><?php echo e($user->mobile); ?></span></a></li>
		                <!-- <li><a href="#"><?php echo e(tr('address')); ?> <span class="pull-right"><?php echo e($user->address); ?></span></a></li> -->
		                <li>
		                	<a href="#"><?php echo e(tr('validity_days')); ?> 
		                		<span class="pull-right"> 
		            				<?php if($user->user_type): ?>
		                                <p style="color:#cc181e">
		                                	<?php echo e(tr('no_of_days_expiry')); ?> 
		                                	<b><?php echo e(get_expiry_days($user->id)); ?> days</b>
		                            	</p>
		                            <?php endif; ?>
		                        </span>
		                    </a>
		                </li>


		                <li>
		                	<a href="#">

		                		<?php echo e(tr('is_moderator')); ?>


		                		<span class="pull-right">

		                			<?php if($user->is_moderator): ?> 
						      			<span class="label label-success"><?php echo e(tr('yes')); ?></span>
						       		<?php else: ?> 
						       			<span class="label label-warning"><?php echo e(tr('no')); ?></span>
						       		<?php endif; ?>
		                		</span>
		                	</a>
		                </li>
		                <li>
		                	<a href="#"><?php echo e(tr('status')); ?> 
		                		<span class="pull-right">
		                			<?php if($user->is_activated): ?> 
						      			<span class="label label-success"><?php echo e(tr('approved')); ?></span>
						       		<?php else: ?> 
						       			<span class="label label-warning"><?php echo e(tr('pending')); ?></span>
						       		<?php endif; ?>
		                		</span>
		                	</a>
		                </li>

		                <li>
		                	<a href="#">

		                		<?php echo e(tr('user_type')); ?>


		                		<span class="pull-right">

		                			<?php if($user->user_type): ?> 
						      			<span class="label label-success"><?php echo e(tr('paid_user')); ?></span>
						       		<?php else: ?> 
						       			<span class="label label-warning"><?php echo e(tr('normal_user')); ?></span>
						       		<?php endif; ?>
		                		</span>
		                	</a>
		                </li>
              		</ul>
            	</div>
          	
          	</div>

		</div>

    </div>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>