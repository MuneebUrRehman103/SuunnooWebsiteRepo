<?php $__env->startSection('title', tr('videos')); ?>

<?php $__env->startSection('content-header', tr('videos')); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li><a href="<?php echo e(route('admin.dashboard')); ?>"><i class="fa fa-dashboard"></i><?php echo e(tr('home')); ?></a></li>
    <li class="active"><i class="fa fa-video-camera"></i> <?php echo e(tr('videos')); ?></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('notification.notify', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<div class="row">
        <div class="col-xs-12">
          <div class="box box-primary">

          	<div class="box-header label-primary">
                <b style="font-size:18px;"><?php echo e(tr('videos')); ?></b>
                <a href="<?php echo e(route('admin.add.video')); ?>" class="btn btn-default pull-right"><?php echo e(tr('add_video')); ?></a>
            </div>

            <div class="box-body">

            	<div class=" table-responsive"> 

            	<?php if(count($videos) > 0): ?>

	              	<table id="example1" class="table table-bordered table-striped text-nowrap">

						<thead>
						    <tr>
						      <th><?php echo e(tr('id')); ?></th>
						      <th><?php echo e(tr('action')); ?></th>
						      <th><?php echo e(tr('position')); ?></th>
						      <th><?php echo e(tr('status')); ?></th>
						      <th><?php echo e(tr('category')); ?></th>
						      <th><?php echo e(tr('sub_category')); ?></th>
						      <th><?php echo e(tr('genre_name')); ?></th>
						      <th><?php echo e(tr('title')); ?></th>
						      <?php if(Setting::get('theme') == 'default'): ?>
						      	<th><?php echo e(tr('slider_video')); ?></th>
						      <?php endif; ?>
						      <?php if(Setting::get('is_payper_view')): ?>
						      	<th><?php echo e(tr('pay_per_view')); ?></th>
						      <?php endif; ?>
						      <th><?php echo e(tr('likes')); ?></th>
								<th><?php echo e(tr('dislikes')); ?></th>
						      <th><?php echo e(tr('viewers_cnt')); ?></th>
						      <th><?php echo e(tr('revenue')); ?></th>
						      <th><?php echo e(tr('uploaded_by')); ?></th>
						      
						    </tr>
						</thead>

						<tbody>
							<?php foreach($videos as $i => $video): ?>

							    <tr>
							      	<td><?php echo e($i+1); ?></td>

								    <td>
            							<ul class="admin-action btn btn-default">
            								<li class="<?php echo e($i < 1 ? 'dropdown' : 'dropup'); ?>">
								                <a class="dropdown-toggle" data-toggle="dropdown" href="#">
								                  <?php echo e(tr('action')); ?> <span class="caret"></span>
								                </a>
								                <ul class="dropdown-menu">
								                	<?php if($video->compress_status == 1 && $video->trailer_compress_status == 1): ?>
								                  	<li role="presentation">
                                                        <?php if(Setting::get('admin_delete_control')): ?>
                                                            <a role="button" href="javascript:;" class="btn disabled" style="text-align: left"><?php echo e(tr('edit')); ?></a>
                                                        <?php else: ?>
                                                            <a role="menuitem" tabindex="-1" href="<?php echo e(route('admin.edit.video' , array('id' => $video->video_id))); ?>"><?php echo e(tr('edit')); ?></a>
                                                        <?php endif; ?>
                                                    </li>
                                                    <?php endif; ?>
								                  	<li role="presentation"><a role="menuitem" tabindex="-1" target="_blank" href="<?php echo e(route('admin.view.video' , array('id' => $video->video_id))); ?>"><?php echo e(tr('view')); ?></a></li>

								                  	<?php if($video->genre_id > 0 && $video->is_approved && $video->status): ?>

								                  	<li role="presentation">
								                		<a role="menuitem" tabindex="-1" role="menuitem" tabindex="-1" data-toggle="modal" data-target="#video_<?php echo e($video->video_id); ?>"><?php echo e(tr('change_position')); ?></a>
								                	</li>

								                	<?php endif; ?>

								                  	<?php if(Setting::get('is_payper_view')): ?>

								                  		<li role="presentation">
								                  			<a role="menuitem" tabindex="-1" data-toggle="modal" data-target="#<?php echo e($video->video_id); ?>"><?php echo e(tr('pay_per_view')); ?></a>
								                  		</li>

								                  	<?php endif; ?>

								                  	<li class="divider" role="presentation"></li>

								                  	<?php if($video->is_approved): ?>
								                		<li role="presentation"><a role="menuitem" tabindex="-1" href="<?php echo e(route('admin.video.decline',$video->video_id)); ?>"><?php echo e(tr('decline')); ?></a></li>
								                	<?php else: ?>
								                		<?php if($video->compress_status == 0 || $video->trailer_compress_status == 0): ?>
								                			<li role="presentation"><a role="menuitem" tabindex="-1"><?php echo e(tr('compress')); ?></a></li>
								                		<?php else: ?> 
								                  			<li role="presentation"><a role="menuitem" tabindex="-1" href="<?php echo e(route('admin.video.approve',$video->video_id)); ?>"><?php echo e(tr('approve')); ?></a></li>
								                  		<?php endif; ?>
								                  	<?php endif; ?>

								                  	<?php if($video->status == 0): ?>
								                  		<li role="presentation"><a role="menuitem" tabindex="-1" href="<?php echo e(route('admin.video.publish-video',$video->video_id)); ?>"><?php echo e(tr('publish')); ?></a></li>
								                  	<?php endif; ?>

								                  	<?php if($video->compress_status == 1 && $video->trailer_compress_status == 1): ?>
									                  	<li class="divider" role="presentation"></li>

									                  	<li role="presentation">
									                  		<?php if(Setting::get('admin_delete_control')): ?>

										                  	 	<a role="button" href="javascript:;" class="btn disabled" style="text-align: left"><?php echo e(tr('delete')); ?></a>

										                  	<?php else: ?>
									                  			<a role="menuitem" tabindex="-1" onclick="return confirm('Are you sure want to delete video? Remaining video positions will Rearrange')" href="<?php echo e(route('admin.delete.video' , array('id' => $video->video_id))); ?>"><?php echo e(tr('delete')); ?></a>
									                  		<?php endif; ?>
									                  	</li>
								                  	<?php endif; ?>
								                </ul>
              								</li>
            							</ul>
								    </td>

							      	<td>

							      		<?php if($video->genre_id > 0): ?>
							      			
								      		<?php if($video->position > 0): ?>

									      	<span class="label label-success"><?php echo e($video->position); ?></span>

									      	<?php else: ?>

									      	<span class="label label-danger"><?php echo e($video->position); ?></span>

									      	<?php endif; ?>

									    <?php else: ?>

									    	<span class="label label-warning"><?php echo e(tr('not_genre')); ?></span>

									    <?php endif; ?>

							      	</td>

							      	<td>
							      		<?php if($video->compress_status == 0 || $video->trailer_compress_status == 0): ?>
							      			<span class="label label-danger"><?php echo e(tr('compress')); ?></span>
							      		<?php else: ?>
								      		<?php if($video->is_approved): ?>
								      			<span class="label label-success"><?php echo e(tr('approved')); ?></span>
								       		<?php else: ?>
								       			<span class="label label-warning"><?php echo e(tr('pending')); ?></span>
								       		<?php endif; ?>
								       	<?php endif; ?>
							      	</td>

							      	<td><?php echo e($video->category_name); ?></td>
							      	<td><?php echo e($video->sub_category_name); ?></td>
							      	<td><?php echo e($video->genre_name ? $video->genre_name : '-'); ?></td>
							      	<td><a href="<?php echo e(route('admin.view.video' , array('id' => $video->video_id))); ?>"><?php echo e(substr($video->title , 0,25)); ?>...</a></td>
							      	<?php if(Setting::get('theme') == 'default'): ?>
							      	<td>
							      		<?php if($video->is_home_slider == 0 && $video->is_approved && $video->status): ?>
							      			<a href="<?php echo e(route('admin.slider.video' , $video->video_id)); ?>"><span class="label label-danger"><?php echo e(tr('set_slider')); ?></span></a>
							      		<?php elseif($video->is_home_slider): ?>
							      			<span class="label label-success"><?php echo e(tr('slider')); ?></span>
							      		<?php else: ?>
							      			-
							      		<?php endif; ?>
							      	</td>

							      	<?php endif; ?>
							      	<?php if(Setting::get('is_payper_view')): ?>
							      	<td class="text-center">
							      		<?php if($video->amount > 0): ?>
							      			<span class="label label-success"><?php echo e(tr('yes')); ?></span>
							      		<?php else: ?>
							      			<span class="label label-danger"><?php echo e(tr('no')); ?></span>
							      		<?php endif; ?>
							      	</td>
							      	<?php endif; ?>

							      	<td><?php echo e(number_format_short($video->getScopeLikeCount->count())); ?></td>

							      	<td><?php echo e(number_format_short($video->getScopeDisLikeCount->count())); ?></td>
							      	<td><?php echo e(number_format_short($video->watch_count)); ?></td>

							      	<td><?php echo e(Setting::get('currency')); ?> <?php echo e($video->admin_amount ? $video->admin_amount : "0.00"); ?></td>

							      	<td>

							      		<?php if(is_numeric($video->uploaded_by)): ?>

							      			<a href="<?php echo e(route('admin.moderator.view',$video->uploaded_by)); ?>"><?php echo e($video->moderator ? $video->moderator->name : ''); ?></a>


							      		<?php else: ?> 

							      			<?php echo e($video->uploaded_by); ?>


							      		<?php endif; ?>

							      	</td>

							    </tr>

								<!-- Modal -->
								<div id="<?php echo e($video->video_id); ?>" class="modal fade" role="dialog">
								  <div class="modal-dialog">
								  <form action="<?php echo e(route('admin.save.video-payment', $video->video_id)); ?>" method="POST">
									    <!-- Modal content-->
									   	<div class="modal-content">
									      <div class="modal-header">
									        <button type="button" class="close" data-dismiss="modal">&times;</button>
									        <h4 class="modal-title"><?php echo e(tr('ppv')); ?></h4>
									      </div>
									      <div class="modal-body">
									        <div class="row">

									        	<input type="hidden" name="ppv_created_by" id="ppv_created_by" value="<?php echo e(Auth::guard('admin')->user()->name); ?>">

									        	<div class="col-lg-3">
									        		<label><?php echo e(tr('type_of_user')); ?></label>
									        	</div>
								                <div class="col-lg-9">
								                  <div class="input-group">
								                        <input type="radio" name="type_of_user" value="<?php echo e(NORMAL_USER); ?>" <?php echo e(($video->type_of_user == 0 || $video->type_of_user == '') ? 'checked' : (($video->type_of_user == NORMAL_USER) ? 'checked' : '')); ?>>&nbsp;<label><?php echo e(tr('normal_user')); ?></label>&nbsp;
								                        <input type="radio" name="type_of_user" value="<?php echo e(PAID_USER); ?>" <?php echo e(($video->type_of_user == PAID_USER) ? 'checked' : ''); ?>>&nbsp;<label><?php echo e(tr('paid_user')); ?></label>&nbsp;
								                        <input type="radio" name="type_of_user" value="<?php echo e(BOTH_USERS); ?>" <?php echo e(($video->type_of_user == BOTH_USERS) ? 'checked' : ''); ?>>&nbsp;<label><?php echo e(tr('both_user')); ?></label>
								                  </div>
								                  <!-- /input-group -->
								                </div>
								            </div>
								            <br>
								            <div class="row">
									        	<div class="col-lg-3">
									        		<label><?php echo e(tr('type_of_subscription')); ?></label>
									        	</div>
								                <div class="col-lg-9">
								                  <div class="input-group">
								                        <input type="radio" name="type_of_subscription" value="<?php echo e(ONE_TIME_PAYMENT); ?>" <?php echo e(($video->type_of_subscription == 0 || $video->type_of_subscription == '') ? 'checked' : (($video->type_of_subscription == ONE_TIME_PAYMENT) ? 'checked' : '')); ?>>&nbsp;<label><?php echo e(tr('one_time_payment')); ?></label>&nbsp;
								                        <input type="radio" name="type_of_subscription" value="<?php echo e(RECURRING_PAYMENT); ?>" <?php echo e(($video->type_of_subscription == RECURRING_PAYMENT) ? 'checked' : ''); ?>>&nbsp;<label><?php echo e(tr('recurring_payment')); ?></label>
								                  </div>
								                  <!-- /input-group -->
								                </div>
								            </div>
								            <br>
								            <div class="row">
									        	<div class="col-lg-3">
									        		<label><?php echo e(tr('amount')); ?></label>
									        	</div>
								                <div class="col-lg-9">
								                       <input type="number" required value="<?php echo e($video->amount); ?>" name="amount" class="form-control" id="amount" placeholder="<?php echo e(tr('amount')); ?>" step="any">
								                  <!-- /input-group -->
								                </div>
								            </div>
									      </div>
									      <div class="modal-footer">
									      	<div class="pull-left">
									      		<?php if($video->amount > 0): ?>
									       			<a class="btn btn-danger" href="<?php echo e(route('admin.remove_pay_per_view', $video->video_id)); ?>"><?php echo e(tr('remove_pay_per_view')); ?></a>
									       		<?php endif; ?>
									       	</div>
									        <div class="pull-right">
										        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
										        <button type="submit" class="btn btn-primary"><?php echo e(tr('submit')); ?></button>
										    </div>
										    <div class="clearfix"></div>
									      </div>
									    </div>
									</form>
								  </div>
								</div>

								<?php if($video->genre_id > 0 && $video->is_approved && $video->status): ?>

								<div id="video_<?php echo e($video->video_id); ?>" class="modal fade" role="dialog">
								  <div class="modal-dialog">
								  <form action="<?php echo e(route('admin.save.video.position',['video_id'=>$video->video_id])); ?>" method="POST">
									    <!-- Modal content-->
									   	<div class="modal-content">
									      <div class="modal-header">
									        <button type="button" class="close" data-dismiss="modal">&times;</button>
									        <h4 class="modal-title"><?php echo e(tr('change_position')); ?></h4>
									      </div>

									      <div class="modal-body">
									        
								            <div class="row">
									        	<div class="col-lg-3">
									        		<label><?php echo e(tr('position')); ?></label>
									        	</div>
								                <div class="col-lg-9">
								                       <input type="number" required value="<?php echo e($video->position); ?>" name="position" class="form-control" id="position" placeholder="<?php echo e(tr('position')); ?>" pattern="[0-9]{1,}" title="Enter 0-9 numbers">
								                  <!-- /input-group -->
								                </div>
								            </div>
									      </div>
									      <div class="modal-footer">
									        <div class="pull-right">
										        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
										        <button type="submit" class="btn btn-primary"><?php echo e(tr('submit')); ?></button>
										    </div>
										    <div class="clearfix"></div>
									      </div>
									    </div>
									</form>
								  </div>
								</div>

								<?php endif; ?>
							<?php endforeach; ?>
						</tbody>
					</table>
				<?php else: ?>
					<h3 class="no-result"><?php echo e(tr('no_video_found')); ?></h3>
				<?php endif; ?>

				</div>
            </div>
          </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>