<?php $__env->startSection('title', tr('settings')); ?>

<?php $__env->startSection('content-header'); ?> 

<?php echo e(tr('settings')); ?> 

<a href="#" id="help-popover" class="btn btn-danger" style="font-size: 14px;font-weight: 600" title=""><?php echo e(tr('help_ques_mark')); ?></a>

<div id="help-content" style="display: none">

    <ul class="popover-list">
        <li><b><?php echo e(tr('paypal')); ?>- </b><?php echo e(tr('minimum_accepted_amount_01')); ?></li>
        <li><b><?php echo e(tr('stripe')); ?>- </b><?php echo e(tr('minimum_accepted_amount')); ?><br> <a target="_blank" href="https://stripe.com/docs/currencies"><?php echo e(tr('check_references')); ?></a></li>
    </ul>
    
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li><a href="<?php echo e(route('admin.dashboard')); ?>"><i class="fa fa-dashboard"></i><?php echo e(tr('home')); ?></a></li>
    <li class="active"><i class="fa fa-gears"></i> <?php echo e(tr('settings')); ?></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">

    <?php echo $__env->make('notification.notify', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    
    <div class="col-md-12">
        <div class="nav-tabs-custom">

                <ul class="nav nav-tabs">
                    <li class="active"><a href="#site_settings" data-toggle="tab"><?php echo e(tr('site_settings')); ?></a></li>
                    <li><a href="#video_settings" data-toggle="tab"><?php echo e(tr('video_settings')); ?></a></li>
                    <li><a href="#revenue_settings" data-toggle="tab"><?php echo e(tr('revenue_settings')); ?></a></li>
                    <li><a href="#social_settings" data-toggle="tab"><?php echo e(tr('social_settings')); ?></a></li>
                    <li><a href="#payment_settings" data-toggle="tab"><?php echo e(tr('payment_settings')); ?></a></li>
                    <li><a href="#email_settings" data-toggle="tab"><?php echo e(tr('email_settings')); ?></a></li>
                    <li><a href="#site_url_settings" data-toggle="tab"><?php echo e(tr('site_url_settings')); ?></a></li>
                    <li><a href="#app_url_settings" data-toggle="tab"><?php echo e(tr('app_url_settings')); ?></a></li>
                    <li><a href="#other_settings" data-toggle="tab"><?php echo e(tr('other_settings')); ?></a></li>
                </ul>
               
                <div class="tab-content">
                   
                    <div class="active tab-pane" id="site_settings">

                        <form action="<?php echo e((Setting::get('admin_delete_control') == 1) ? '' : route('admin.save.settings')); ?>" method="POST" enctype="multipart/form-data" role="form">

                            <div class="box-body">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="sitename"><?php echo e(tr('site_name')); ?></label>
                                        <input type="text" class="form-control" name="site_name" value="<?php echo e(Setting::get('site_name')); ?>" id="sitename" placeholder="Enter sitename">
                                    </div>
                                </div>

                                <div class="col-lg-6">

                                    <div class="form-group">

                                        <label for="streaming_url"><?php echo e(tr('ANGULAR_SITE_URL')); ?></label>

                                        <!-- <p class="example-note"><?php echo e(tr('angular_url_note')); ?></p> -->

                                        <input type="text" value="<?php echo e(Setting::get('ANGULAR_SITE_URL')); ?>" class="form-control" name="ANGULAR_SITE_URL" id="ANGULAR_SITE_URL" placeholder="Enter App URL">
                                    </div> 

                                </div>


                                <div class="col-md-3">
                                    <div class="form-group">
                                       
                                        <label for="site_logo"><?php echo e(tr('site_logo')); ?></label>

                                        <br>

                                        <?php if(Setting::get('site_logo')): ?>
                                            <img class="settings-img-preview " src="<?php echo e(Setting::get('site_logo')); ?>" title="<?php echo e(Setting::get('sitename')); ?>">
                                        <?php endif; ?>

                                        <input type="file" id="site_logo" name="site_logo" accept="image/png, image/jpeg">
                                        <p class="help-block"><?php echo e(tr('image_note_help')); ?></p>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">

                                        <label for="site_icon"><?php echo e(tr('site_icon')); ?></label>

                                        <br>

                                        <?php if(Setting::get('site_icon')): ?>
                                            <img class="settings-img-preview " src="<?php echo e(Setting::get('site_icon')); ?>" title="<?php echo e(Setting::get('sitename')); ?>">
                                        <?php endif; ?>
                                        <input type="file" id="site_icon" name="site_icon" accept="image/png, image/jpeg">
                                        <p class="help-block"><?php echo e(tr('image_note_help')); ?></p>
                                    </div>
                                </div>

                                <div class="col-md-3">

                                    <div class="form-group">


                                        <label for="home_page_bg_image"><?php echo e(tr('home_page_bg_image')); ?></label>

                                        <br>

                                        <?php if(Setting::get('home_page_bg_image')): ?>
                                            <img class="settings-img-preview " src="<?php echo e(Setting::get('home_page_bg_image')); ?>" title="<?php echo e(Setting::get('sitename')); ?>">
                                        <?php endif; ?>

                                        <input type="file" id="home_page_bg_image" name="home_page_bg_image" accept="image/png, image/jpeg">
                                        <p class="help-block"><?php echo e(tr('image_note_help')); ?></p>
                                    </div>
                                </div>

                                <div class="col-md-3">
                                    <div class="form-group">
                                        
                                        <label for="common_bg_image"><?php echo e(tr('common_bg_image')); ?></label>
                                        <br>
                                        <?php if(Setting::get('common_bg_image')): ?>
                                            <img class="settings-img-preview " src="<?php echo e(Setting::get('common_bg_image')); ?>" title="<?php echo e(Setting::get('sitename')); ?>">
                                        <?php endif; ?>
                                        <input type="file" id="common_bg_image" name="common_bg_image" accept="image/png, image/jpeg">
                                        <p class="help-block"><?php echo e(tr('image_note_help')); ?></p>
                                    </div>
                                </div>

                          </div>
                          <!-- /.box-body -->

                          <div class="box-footer">
                            <?php if(Setting::get('admin_delete_control') == 1): ?>
                                <button type="submit" class="btn btn-primary" disabled><?php echo e(tr('submit')); ?></button>
                            <?php else: ?>
                                <button type="submit" class="btn btn-primary"><?php echo e(tr('submit')); ?></button>
                            <?php endif; ?>
                          </div>
                        
                        </form>
                    
                    </div>

                    <div class="tab-pane" id="video_settings">

                        <form action="<?php echo e((Setting::get('admin_delete_control') == 1) ? '' : route('admin.save.common-settings')); ?>" method="POST" enctype="multipart/form-data" role="form">


                            <div class="box-body">

                                <h3 class="settings-sub-header"><?php echo e(tr('player_configuration')); ?></h3>
                                <hr>

                                <div class="col-lg-6">
                                    <div class="form-group">

                                        <label for="streaming_url"><?php echo e(tr('jwplayer_key')); ?></label>

                                        <input type="text" value="<?php echo e(Setting::get('JWPLAYER_KEY')); ?>" class="form-control" name="JWPLAYER_KEY" id="JWPLAYER_KEY" placeholder="<?php echo e(tr('jwplayer_key')); ?>">
                                    </div> 
                                </div>

                                <div class="col-lg-6">
                                    <div class="form-group">

                                        <label for="streaming_url"><?php echo e(tr('socket_url')); ?></label>

                                        <input type="text" value="<?php echo e(Setting::get('socket_url')); ?>" class="form-control" name="socket_url" id="socket_url" placeholder="<?php echo e(tr('socket_url')); ?>">
                                    </div> 
                                </div>

                                <div class="clearfix"></div>

                                <div class="col-lg-6">
                                    <div class="form-group">

                                        <label for="streaming_url"><?php echo e(tr('admin_url')); ?></label>

                                        <input type="text" value="<?php echo e($result['SOCKET_URL']); ?>" class="form-control" name="SOCKET_URL" id="SOCKET_URL" placeholder="<?php echo e(tr('socket_url')); ?>">
                                    </div> 
                                </div>

                                <div class="clearfix"></div>



                                <!-- Streaming Configuration start -->

                                <h3 class="settings-sub-header"><?php echo e(tr('streaming_configuration')); ?></h3>
                                <hr>


                                <div class="col-lg-6">
                                    <div class="form-group">

                                        <label for="streaming_url"><?php echo e(tr('streaming_url')); ?></label>

                                        <br>

                                        <p class="example-note"><?php echo e(tr('rtmp_settings_note')); ?></p>

                                        <input type="text" value="<?php echo e(Setting::get('streaming_url')); ?>" class="form-control" name="streaming_url" id="streaming_url" placeholder="<?php echo e(tr('enter_streaming_url')); ?>">
                                    </div> 
                                </div>

                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label for="HLS_STREAMING_URL"><?php echo e(tr('HLS_STREAMING_URL')); ?></label>
                                        
                                        <br>

                                        <p class="example-note"><?php echo e(tr('hls_settings_note')); ?></p>

                                        <input type="text" value="<?php echo e(Setting::get('HLS_STREAMING_URL')); ?>" class="form-control" name="HLS_STREAMING_URL" id="HLS_STREAMING_URL" placeholder="<?php echo e(tr('enter_streaming_url')); ?>">
                                    </div> 
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="post_max_size"><?php echo e(tr('post_max_size_label')); ?></label>
                                        <br>

                                        <p class="example-note"><?php echo e(tr('post_max_size_label_note')); ?></p>
                                        <input type="text" class="form-control" name="post_max_size" value="<?php echo e(Setting::get('post_max_size')); ?>" id="post_max_size" placeholder="<?php echo e(tr('post_max_size_label')); ?>">
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="upload_max_size"><?php echo e(tr('max_upload_size_label')); ?></label>
                                        <br>

                                        <p class="example-note"><?php echo e(tr('max_upload_size_label_note')); ?></p>
                                        <input type="text" class="form-control" name="upload_max_size" value="<?php echo e(Setting::get('upload_max_size')); ?>" id="upload_max_size" placeholder="<?php echo e(tr('max_upload_size_label')); ?>">
                                    </div>
                                </div>

                                <div class="clearfix"></div>

                                <!-- Streaming Configuration END -->

                                <h3 class="settings-sub-header"><?php echo e(tr('s3_settings')); ?></h3>
                                <hr>

                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label for="s3_key"><?php echo e(tr('S3_KEY')); ?></label>
                                        <input type="text" class="form-control" name="S3_KEY" id="s3_key" placeholder="<?php echo e(tr('S3_KEY')); ?>" value="<?php echo e($result['S3_KEY']); ?>">
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label for="s3_secret"><?php echo e(tr('S3_SECRET')); ?></label>    
                                        <input type="text" class="form-control" name="S3_SECRET" id="s3_secret" placeholder="<?php echo e(tr('S3_SECRET')); ?>" value="<?php echo e($result['S3_SECRET']); ?>">
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label for="s3_region"><?php echo e(tr('S3_REGION')); ?></label>    
                                        <input type="text" class="form-control" name="S3_REGION" id="s3_region" placeholder="<?php echo e(tr('S3_REGION')); ?>" value="<?php echo e($result['S3_REGION']); ?>">
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label for="s3_bucket"><?php echo e(tr('S3_BUCKET')); ?></label>    
                                        <input type="text" class="form-control" name="S3_BUCKET" id="s3_bucket" placeholder="<?php echo e(tr('S3_BUCKET')); ?>" value="<?php echo e($result['S3_BUCKET']); ?>">
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label for="s3_ses_region"><?php echo e(tr('S3_SES_REGION')); ?></label>    
                                        <input type="text" class="form-control" name="S3_SES_REGION" id="s3_ses_region" placeholder="<?php echo e(tr('S3_SES_REGION')); ?>" value="<?php echo e($result['S3_SES_REGION']); ?>">
                                    </div>
                                </div>
                                <div class="clearfix"></div>

                            </div>
                            <div class="box-footer">
                                <?php if(Setting::get('admin_delete_control') == 1): ?> 
                                    <button type="submit" class="btn btn-primary" disabled><?php echo e(tr('submit')); ?></button>
                                <?php else: ?>
                                    <button type="submit" class="btn btn-primary"><?php echo e(tr('submit')); ?></button>
                                <?php endif; ?>
                          </div>
                        </form>

                    </div>

                    <div class="tab-pane" id="revenue_settings">

                        <form action="<?php echo e((Setting::get('admin_delete_control') == 1) ? '' : route('admin.save.common-settings')); ?>" method="POST" enctype="multipart/form-data" role="form">
                            <div class="box-body">
                                <div class="col-md-12">
                                    <div class="form-group">

                                        <label for="upload_max_size"><?php echo e(tr('video_viewer_count_size_label')); ?></label>

                                        <br>

                                        <p class="example-note"><?php echo e(tr('video_viewer_count_size_label_note')); ?></p>

                                        <input type="text" class="form-control" name="video_viewer_count" value="<?php echo e(Setting::get('video_viewer_count')); ?>" id="video_viewer_count" placeholder="<?php echo e(tr('video_viewer_count_size_label')); ?>">
                                    </div>
                                </div>

                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="upload_max_size"><?php echo e(tr('amount_per_video')); ?></label>
                                        
                                        <br>
                                        
                                        <p class="example-note"><?php echo e(tr('amount_per_video_note')); ?></p>

                                        <input type="text" class="form-control" name="amount_per_video" value="<?php echo e(Setting::get('amount_per_video')); ?>" min="0.5" id="amount_per_video" placeholder="<?php echo e(tr('amount_per_video')); ?>">

                                    </div>
                                </div>

                                 <div class="col-md-6">
                                    <div class="form-group">

                                        <label for="upload_max_size"><?php echo e(tr('admin_commission')); ?></label>

                                        <input type="text" class="form-control" name="admin_commission" value="<?php echo e(Setting::get('admin_commission')); ?>" id="admin_commission" placeholder="<?php echo e(tr('admin_commission')); ?>">
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="upload_max_size"><?php echo e(tr('moderator_commission')); ?></label>
                                        <input type="text" class="form-control" name="user_commission" value="<?php echo e(Setting::get('user_commission')); ?>" id="user_commission" placeholder="<?php echo e(tr('moderator_commission')); ?>">
                                    </div>
                                </div>
                                <div class="clearfix"></div>
                                
                            </div>
                            <div class="box-footer">
                                <?php if(Setting::get('admin_delete_control') == 1): ?> 
                                    <button type="submit" class="btn btn-primary" disabled><?php echo e(tr('submit')); ?></button>
                                <?php else: ?>
                                    <button type="submit" class="btn btn-primary"><?php echo e(tr('submit')); ?></button>
                                <?php endif; ?>
                          </div>
                        </form>

                    </div>

                    <div class="tab-pane" id="social_settings">

                        <form action="<?php echo e((Setting::get('admin_delete_control') == 1) ? '' : route('admin.save.common-settings')); ?>" method="POST" enctype="multipart/form-data" role="form">
                            <div class="box-body">
                                <h4><?php echo e(tr('fb_settings')); ?></h4>
                                <hr>
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label for="fb_client_id"><?php echo e(tr('FB_CLIENT_ID')); ?></label>
                                        <input type="text" class="form-control" name="FB_CLIENT_ID" id="fb_client_id" placeholder="<?php echo e(tr('FB_CLIENT_ID')); ?>" value="<?php echo e($result['FB_CLIENT_ID']); ?>">
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label for="fb_client_secret"><?php echo e(tr('FB_CLIENT_SECRET')); ?></label>    
                                        <input type="text" class="form-control" name="FB_CLIENT_SECRET" id="fb_client_secret" placeholder="<?php echo e(tr('FB_CLIENT_SECRET')); ?>" value="<?php echo e($result['FB_CLIENT_SECRET']); ?>">
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label for="fb_call_back"><?php echo e(tr('FB_CALL_BACK')); ?></label>    
                                        <input type="text" class="form-control" name="FB_CALL_BACK" id="fb_call_back" placeholder="<?php echo e(tr('FB_CALL_BACK')); ?>" value="<?php echo e($result['FB_CALL_BACK']); ?>">
                                    </div>
                                </div>
                                <div class="clearfix"></div>
                                <!-- <h4><?php echo e(tr('twitter_settings')); ?></h4>
                                <hr>
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label for="twitter_client_id"><?php echo e(tr('TWITTER_CLIENT_ID')); ?></label>
                                        <input type="text" class="form-control" name="TWITTER_CLIENT_ID" id="twitter_client_id" placeholder="<?php echo e(tr('TWITTER_CLIENT_ID')); ?>" value="<?php echo e($result['TWITTER_CLIENT_ID']); ?>">
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label for="twitter_client_secret"><?php echo e(tr('TWITTER_CLIENT_SECRET')); ?></label>    
                                        <input type="text" class="form-control" name="TWITTER_CLIENT_SECRET" id="twitter_client_secret" placeholder="<?php echo e(tr('TWITTER_CLIENT_SECRET')); ?>" value="<?php echo e($result['TWITTER_CLIENT_SECRET']); ?>">
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label for="twitter_call_back"><?php echo e(tr('TWITTER_CALL_BACK')); ?></label>    
                                        <input type="text" class="form-control" name="TWITTER_CALL_BACK" id="twitter_call_back" placeholder="<?php echo e(tr('TWITTER_CALL_BACK')); ?>" value="<?php echo e($result['TWITTER_CALL_BACK']); ?>">
                                    </div>
                                </div>
                                <div class="clearfix"></div> -->
                                <h4><?php echo e(tr('google_settings')); ?></h4>
                                <hr>
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label for="google_client_id"><?php echo e(tr('GOOGLE_CLIENT_ID')); ?></label>
                                        <input type="text" class="form-control" name="GOOGLE_CLIENT_ID" id="google_client_id" placeholder="<?php echo e(tr('GOOGLE_CLIENT_ID')); ?>" value="<?php echo e($result['GOOGLE_CLIENT_ID']); ?>">
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label for="google_client_secret"><?php echo e(tr('GOOGLE_CLIENT_SECRET')); ?></label>    
                                        <input type="text" class="form-control" name="GOOGLE_CLIENT_SECRET" id="google_client_secret" placeholder="<?php echo e(tr('GOOGLE_CLIENT_SECRET')); ?>" value="<?php echo e($result['GOOGLE_CLIENT_SECRET']); ?>">
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label for="google_call_back"><?php echo e(tr('GOOGLE_CALL_BACK')); ?></label>    
                                        <input type="text" class="form-control" name="GOOGLE_CALL_BACK" id="google_call_back" placeholder="<?php echo e(tr('GOOGLE_CALL_BACK')); ?>" value="<?php echo e($result['GOOGLE_CALL_BACK']); ?>">
                                    </div>
                                </div>
                                <div class='clearfix'></div>
                            </div>
                            <div class="box-footer">
                                <?php if(Setting::get('admin_delete_control') == 1): ?> 
                                    <button type="submit" class="btn btn-primary" disabled><?php echo e(tr('submit')); ?></button>
                                <?php else: ?>
                                    <button type="submit" class="btn btn-primary"><?php echo e(tr('submit')); ?></button>
                                <?php endif; ?>
                          </div>
                        </form>

                    </div>

                    <div class="tab-pane" id="payment_settings">

                        <form action="<?php echo e((Setting::get('admin_delete_control') == 1) ? '' : route('admin.save.common-settings')); ?>" method="POST" enctype="multipart/form-data" role="form">
                            <div class="box-body">
    
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label for="paypal_id"><?php echo e(tr('PAYPAL_ID')); ?></label>
                                        <input type="text" class="form-control" name="PAYPAL_ID" id="paypal_id" placeholder="<?php echo e(tr('PAYPAL_ID')); ?>" value="<?php echo e($result['PAYPAL_ID']); ?>">
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label for="paypal_secret"><?php echo e(tr('PAYPAL_SECRET')); ?></label>    
                                        <input type="text" class="form-control" name="PAYPAL_SECRET" id="paypal_secret" placeholder="<?php echo e(tr('PAYPAL_SECRET')); ?>" value="<?php echo e($result['PAYPAL_SECRET']); ?>">
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label for="paypal_mode"><?php echo e(tr('PAYPAL_MODE')); ?></label>    
                                        <input type="text" class="form-control" name="PAYPAL_MODE" id="paypal_mode" placeholder="<?php echo e(tr('PAYPAL_MODE')); ?>" value="<?php echo e($result['PAYPAL_MODE']); ?>">
                                    </div>
                                </div>

                                <div class="clearfix"></div>

                                <hr>

                                <h3><?php echo e(tr('stripe_settings')); ?></h3>

                                <hr>

                                 <div class="col-lg-6">
                                    <div class="form-group">
                                        <label for="paypal_id"><?php echo e(tr('stripe_publishable_key')); ?></label>
                                        <input type="text" class="form-control" name="stripe_publishable_key" id="stripe_publishable_key" placeholder="<?php echo e(tr('stripe_publishable_key')); ?>" value="<?php echo e(Setting::get('stripe_publishable_key')); ?>">
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label for="paypal_secret"><?php echo e(tr('stripe_secret_key')); ?></label>
                                        <input type="text" class="form-control" name="stripe_secret_key" id="stripe_secret_key" placeholder="<?php echo e(tr('stripe_secret_key')); ?>" value="<?php echo e(Setting::get('stripe_secret_key')); ?>">
                                    </div>
                                </div>

                            </div>
                            <div class="box-footer">
                                <?php if(Setting::get('admin_delete_control') == 1): ?> 
                                    <button type="submit" class="btn btn-primary" disabled><?php echo e(tr('submit')); ?></button>
                                <?php else: ?>
                                    <button type="submit" class="btn btn-primary"><?php echo e(tr('submit')); ?></button>
                                <?php endif; ?>
                          </div>
                        </form>

                    </div>

                    <div class="tab-pane" id="email_settings">
                        <form action="<?php echo e(route('admin.email.settings.save')); ?>" method="POST" enctype="multipart/form-data" role="form">
                            
                            <div class="box-body">

                                <div class="col-md-6">

                                    <div class="form-group">
                                        <label for="paypal_client_id"><?php echo e(tr('MAIL_DRIVER')); ?></label>
                                        <input type="text" value="<?php echo e($result['MAIL_DRIVER']); ?>" class="form-control" name="MAIL_DRIVER" id="MAIL_DRIVER" placeholder="Enter <?php echo e(tr('MAIL_DRIVER')); ?>">
                                    </div>

                                    <div class="form-group">
                                        <label for="MAIL_HOST"><?php echo e(tr('MAIL_HOST')); ?></label>
                                        <input type="text" class="form-control" value="<?php echo e($result['MAIL_HOST']); ?>" name="MAIL_HOST" id="MAIL_HOST" placeholder="<?php echo e(tr('MAIL_HOST')); ?>">
                                    </div>

                                    <div class="form-group">
                                        <label for="MAIL_PORT"><?php echo e(tr('MAIL_PORT')); ?></label>
                                        <input type="text" class="form-control" value="<?php echo e($result['MAIL_PORT']); ?>" name="MAIL_PORT" id="MAIL_PORT" placeholder="<?php echo e(tr('MAIL_PORT')); ?>">
                                    </div>

                                </div>

                                <div class="col-md-6">

                                    <div class="form-group">
                                        <label for="MAIL_USERNAME"><?php echo e(tr('MAIL_USERNAME')); ?></label>
                                        <input type="text" class="form-control" value="<?php echo e($result['MAIL_USERNAME']); ?>" name="MAIL_USERNAME" id="MAIL_USERNAME" placeholder="<?php echo e(tr('MAIL_USERNAME')); ?>">
                                    </div>

                                    <div class="form-group">
                                        <label for="MAIL_PASSWORD"><?php echo e(tr('MAIL_PASSWORD')); ?></label>
                                        <input type="password" class="form-control" name="MAIL_PASSWORD" id="MAIL_PASSWORD" placeholder="<?php echo e(tr('MAIL_PASSWORD')); ?>" value="<?php echo e($result['MAIL_PASSWORD']); ?>">
                                    </div>

                                    <div class="form-group">
                                        <label for="MAIL_PORT"><?php echo e(tr('MAIL_ENCRYPTION')); ?></label>
                                        <input type="text" class="form-control" value="<?php echo e($result['MAIL_ENCRYPTION']); ?>" name="MAIL_ENCRYPTION" id="MAIL_ENCRYPTION" placeholder="<?php echo e(tr('MAIL_ENCRYPTION')); ?>">
                                    </div>

                                </div>

                                <div class="clearfix"></div>

                                <?php if($result['MAIL_DRIVER'] == 'mailgun'): ?>

                                <div class="col-md-12">

                                    <div class="form-group">
                                        <label for="MAILGUN_DOMAIN"><?php echo e(tr('MAILGUN_DOMAIN')); ?></label>
                                        <input type="text" class="form-control" value="<?php echo e($result['MAILGUN_DOMAIN']); ?>" name="MAILGUN_DOMAIN" id="MAILGUN_DOMAIN" placeholder="<?php echo e(tr('MAILGUN_DOMAIN')); ?>">
                                    </div>

                                    <div class="form-group">
                                        <label for="MAILGUN_SECRET"><?php echo e(tr('MAILGUN_SECRET')); ?></label>
                                        <input type="text" class="form-control" name="MAILGUN_SECRET" id="MAILGUN_SECRET" placeholder="<?php echo e(tr('MAILGUN_SECRET')); ?>" value="<?php echo e($result['MAILGUN_SECRET']); ?>">
                                    </div>

                                </div>

                                <?php endif; ?>

                          </div>
                          <!-- /.box-body -->

                            <div class="box-footer">
                                <?php if(Setting::get('admin_delete_control')): ?>
                                    <a href="#" class="btn btn-success pull-right" disabled><?php echo e(tr('submit')); ?></a>
                                <?php else: ?>
                                    <button type="submit" class="btn btn-success pull-right"><?php echo e(tr('submit')); ?></button>
                                <?php endif; ?>
                            </div>
                        </form>
                    </div>

                    <div class="tab-pane" id="site_url_settings">

                        <form action="<?php echo e((Setting::get('admin_delete_control') == 1) ? '' : route('admin.save.common-settings')); ?>" method="POST" enctype="multipart/form-data" role="form">
                            <div class="box-body">
                                <div class="col-md-6">
                                    <div class="form-group">

                                        <label for="upload_max_size"><?php echo e(tr('facebook_link')); ?></label>

                                        <input type="url" class="form-control" name="facebook_link" id="facebook_link"
                                        value="<?php echo e(Setting::get('facebook_link')); ?>" placeholder="<?php echo e(tr('facebook_link')); ?>">
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="upload_max_size"><?php echo e(tr('linkedin_link')); ?></label>

                                        <input type="url" class="form-control" name="linkedin_link" value="<?php echo e(Setting::get('linkedin_link')); ?>" id="linkedin_link" placeholder="<?php echo e(tr('linkedin_link')); ?>">

                                    </div>
                                </div>

                                 <div class="col-md-6">
                                    <div class="form-group">

                                        <label for="upload_max_size"><?php echo e(tr('twitter_link')); ?></label>

                                        <input type="url" class="form-control" name="twitter_link" value="<?php echo e(Setting::get('twitter_link')); ?>" id="twitter_link" placeholder="<?php echo e(tr('twitter_link')); ?>">
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="upload_max_size"><?php echo e(tr('google_plus_link')); ?></label>
                                        <input type="url" class="form-control" name="google_plus_link" value="<?php echo e(Setting::get('google_plus_link')); ?>" id="google_plus_link" placeholder="<?php echo e(tr('google_plus_link')); ?>">
                                    </div>
                                </div>


                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="upload_max_size"><?php echo e(tr('pinterest_link')); ?></label>
                                        <input type="url" class="form-control" name="pinterest_link" value="<?php echo e(Setting::get('pinterest_link')); ?>" id="pinterest_link" placeholder="<?php echo e(tr('pinterest_link')); ?>">
                                    </div>
                                </div>
                                <div class="clearfix"></div>
                                
                            </div>
                            <div class="box-footer">
                                <?php if(Setting::get('admin_delete_control') == 1): ?> 
                                    <button type="submit" class="btn btn-primary" disabled><?php echo e(tr('submit')); ?></button>
                                <?php else: ?>
                                    <button type="submit" class="btn btn-primary"><?php echo e(tr('submit')); ?></button>
                                <?php endif; ?>
                          </div>
                        </form>

                    </div>

                    <div class="tab-pane" id="app_url_settings">

                        <form action="<?php echo e((Setting::get('admin_delete_control') == 1) ? '' : route('admin.save.settings')); ?>" method="POST" enctype="multipart/form-data" role="form">
                            <div class="box-body">
                                <div class="col-md-6">
                                    <div class="form-group">

                                        <label for="upload_max_size"><?php echo e(tr('appstore')); ?></label>

                                        <input type="url" class="form-control" name="appstore" id="appstore"
                                        value="<?php echo e(Setting::get('appstore')); ?>" placeholder="<?php echo e(tr('appstore')); ?>">
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="upload_max_size"><?php echo e(tr('playstore')); ?></label>

                                        <input type="url" class="form-control" name="playstore" value="<?php echo e(Setting::get('playstore')); ?>" id="playstore" placeholder="<?php echo e(tr('playstore')); ?>">

                                    </div>
                                </div>
                                
                            </div>
                            <div class="box-footer">
                                <?php if(Setting::get('admin_delete_control') == 1): ?> 
                                    <button type="submit" class="btn btn-primary" disabled><?php echo e(tr('submit')); ?></button>
                                <?php else: ?>
                                    <button type="submit" class="btn btn-primary"><?php echo e(tr('submit')); ?></button>
                                <?php endif; ?>
                          </div>
                        </form>

                    </div>
                    <div class="tab-pane" id="other_settings">

                        <form action="<?php echo e((Setting::get('admin_delete_control') == 1) ? '' : route('admin.other.settings.save')); ?>" method="POST" enctype="multipart/form-data" r  ole="form">
                            
                            <div class="box-body"> 

                                <div class="col-lg-12">

                                    <div class="form-group">
                                        <label for="google_analytics"><?php echo e(tr('google_analytics')); ?></label>
                                        <textarea class="form-control" id="google_analytics" name="google_analytics"><?php echo e(Setting::get('google_analytics')); ?></textarea>
                                    </div>

                                </div> 

                                <div class="col-lg-12">

                                    <div class="form-group">
                                        <label for="header_scripts"><?php echo e(tr('header_scripts')); ?></label>
                                        <textarea class="form-control" id="header_scripts" name="header_scripts"><?php echo e(Setting::get('header_scripts')); ?></textarea>
                                    </div>

                                </div> 

                                <div class="col-lg-12">

                                    <div class="form-group">
                                        <label for="body_scripts"><?php echo e(tr('body_scripts')); ?></label>
                                        <textarea class="form-control" id="body_scripts" name="body_scripts"><?php echo e(Setting::get('body_scripts')); ?></textarea>
                                    </div>
                                </div> 

                                <div class="col-lg-12">

                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label for="upload_max_size"><?php echo e(tr('token_expiry_hour')); ?></label>

                                            <input type="number" class="form-control" name="token_expiry_hour" value="<?php echo e(Setting::get('token_expiry_hour')); ?>" id="token_expiry_hour" placeholder="<?php echo e(tr('token_expiry_hour')); ?>" pattern="[0-9]{1,}" maxlength="2">
                                        </div>
                                    </div>

                                    <div class="col-md-4">

                                        <div class="form-group">
                                            <label for="custom_user"><?php echo e(tr('custom_user')); ?></label>
                                            <input type="text" class="form-control" value="<?php echo e(Setting::get('custom_users_count')); ?>" name=" custom_users_count" id="custom_users_count" placeholder="<?php echo e(tr('custom_user_count')); ?>">
                                        </div>
                                    </div>

                                    <div class="col-md-4">
                                        
                                        <div class="form-group">
                                            <label for="upload_max_size"><?php echo e(tr('email_notification')); ?></label>
                                            <div class="clearfix"></div>

                                            <input type="checkbox" name="email_notification" value="1" id="email_notification" <?php if(Setting::get('email_notification')): ?> checked <?php endif; ?>><?php echo e(tr('enable_email_notification_to_user')); ?>

                                        </div>

                                    </div>
                                </div>

                                <?php if(Setting::get('admin_language_control') == 0): ?>

                                <div class="col-lg-4">

                                    <div class="form-group">
                                        <label for="amount"><?php echo e(tr('default_lang')); ?></label>

                                        <select class="form-control select2" name="default_lang" id="default_lang" required>

                                            <option value=""><?php echo e(tr('language')); ?></option>
                                                <?php foreach($languages as $h => $language): ?>
                                                    <option value="<?php echo e($language->folder_name); ?>" <?php echo e((Setting::get('default_lang') == $language->folder_name) ? 'selected' : Setting::get('default_lang')); ?>><?php echo e($language->language); ?>(<?php echo e($language->folder_name); ?>)</option>
                                                <?php endforeach; ?>
                                            
                                            </select>
                                    </div> 

                                </div>  

                                <?php endif; ?>

                          </div>
                          <!-- /.box-body -->

                          <div class="box-footer">
                            <?php if(Setting::get('admin_delete_control') == 1): ?> 
                                <button type="submit" class="btn btn-primary" disabled><?php echo e(tr('submit')); ?></button>
                            <?php else: ?>
                                <button type="submit" class="btn btn-primary"><?php echo e(tr('submit')); ?></button>
                            <?php endif; ?>
                          </div>
                        </form>
                    
                    </div>

                </div>

            </div>
        </div>
    
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>